LAB 7 - QUAN LY NHAN SU CONG TY SON DONG A
===========================================

CAC TEP
- QuanLyNhanSu.SonDongA.sln: mo bang Visual Studio 2022.
- QuanLyNhanSu.WinForms/: ma nguon ung dung Windows Forms (C# / .NET 8).
- QuanLyNhanSu_DongA.sql: tao co so du lieu SQL Server.

CACH CHAY
1. Mo SQL Server Management Studio (SSMS), ket noi SQL Server cua ban.
2. Mo va Execute file QuanLyNhanSu_DongA.sql. Script tao database QuanLyNhanSu_DongA va cac bang.
3. Mo QuanLyNhanSu.SonDongA.sln bang Visual Studio 2022.
4. Cho NuGet restore goi Microsoft.Data.SqlClient; neu Visual Studio hoi tai package thi dong y.
5. Mo file QuanLyNhanSu.WinForms/Db.cs va sua Server trong chuoi ket noi cho dung instance SQL cua ban.
   Mac dinh: Server=localhost. Neu dung SQL Express, thu Server=.\SQLEXPRESS.
   Neu dung LocalDB, thu Server=(localdb)\MSSQLLocalDB.
6. Chon project QuanLyNhanSu.WinForms lam Startup Project, nhan F5.

CAC CHUC NANG TRONG BAN KHOI TAO
- Xem du lieu cua 19 bang nghiep vu.
- Them dong, sua truc tiep tren luoi, danh dau xoa va luu thay doi.
- Chuyen module bang danh sach o tren cung va tai lai du lieu.

LUU Y
- Ung dung nay la bo ma khoi tao de thao tac CRUD co ban tren cac bang; chua phai he thong nghiep vu hoan chinh.
- Cac khoa ngoai, gia tri bat buoc va quy tac tinh luong van duoc SQL Server kiem tra. Neu luu loi, doc thong bao va dien truong/tham chieu con thieu.
- Ty le bao hiem, gio cong chuan va cong thuc luong trong SQL can duoc xac nhan theo yeu cau giang vien/cong ty truoc khi su dung thuc te.
- Yeu cau .NET 8 SDK va Visual Studio 2022 co workload .NET desktop development.
