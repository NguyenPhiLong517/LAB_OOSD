using Microsoft.Data.SqlClient;

namespace QuanLyNhanSu.WinForms;

internal static class Db
{
    // Sua Server cho dung may SQL Server cua ban:
    // - SQL Server local: localhost
    // - SQL Server Express: .\\SQLEXPRESS
    // - LocalDB: (localdb)\\MSSQLLocalDB
    internal static string ConnectionString { get; set; } =
        "Server=localhost;Database=QuanLyNhanSu_DongA;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;";

    internal static SqlConnection CreateConnection() => new(ConnectionString);
}
