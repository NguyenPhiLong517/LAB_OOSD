using System.Data;
using Microsoft.Data.SqlClient;

namespace QuanLyNhanSu.WinForms;

public sealed class MainForm : Form
{
    private readonly ComboBox _module = new();
    private readonly DataGridView _grid = new();
    private readonly Label _status = new();
    private readonly ToolStripStatusLabel _footerStatus = new();
    private SqlConnection? _connection;
    private SqlDataAdapter? _adapter;
    private SqlCommandBuilder? _commandBuilder;
    private DataTable? _table;
    private string _currentTable = "NHAN_VIEN";

    private static readonly (string Table, string Caption)[] Modules =
    {
        ("PHONG_BAN", "Phòng ban"),
        ("CHUC_VU", "Chức vụ"),
        ("NHAN_VIEN", "Nhân viên"),
        ("QUYET_DINH_TUYEN_DUNG", "Quyết định tuyển dụng"),
        ("HOP_DONG_LAO_DONG", "Hợp đồng lao động"),
        ("QUYET_DINH_CHUC_VU", "Quyết định chức vụ"),
        ("QUYET_DINH_LUONG", "Quyết định lương"),
        ("HO_SO_BAO_HIEM", "Hồ sơ bảo hiểm"),
        ("CA_LAM_VIEC", "Ca làm việc"),
        ("KE_HOACH_PHAN_CONG", "Kế hoạch phân công ca"),
        ("PHIEU_CHAM_CONG", "Phiếu chấm công"),
        ("CHI_TIET_CHAM_CONG", "Chi tiết chấm công"),
        ("PHIEU_PHU_TROI", "Phiếu phụ trội / tăng ca"),
        ("CHI_TIET_PHU_TROI", "Chi tiết phụ trội"),
        ("BANG_LUONG", "Bảng lương"),
        ("QUYET_DINH_KHEN_THUONG", "Quyết định khen thưởng"),
        ("PHIEU_CHI_KHEN_THUONG", "Phiếu chi khen thưởng"),
        ("QUYET_DINH_KY_LUAT", "Quyết định kỷ luật"),
        ("PHIEU_THU_NOP_PHAT", "Phiếu thu / nộp phạt")
    };

    public MainForm()
    {
        Text = "QUẢN LÝ NHÂN SỰ — CÔNG TY SƠN ĐÔNG Á";
        StartPosition = FormStartPosition.CenterScreen;
        Width = 1320;
        Height = 780;
        MinimumSize = new Size(980, 600);
        Font = new Font("Segoe UI", 9F);
        BuildLayout();
        Shown += (_, _) => LoadSelectedTable();
    }

    private void BuildLayout()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(12)
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 94));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        Controls.Add(root);

        var header = new Panel { Dock = DockStyle.Fill };
        var title = new Label
        {
            Text = "HỆ THỐNG QUẢN LÝ NHÂN SỰ",
            Font = new Font("Segoe UI", 18F, FontStyle.Bold),
            AutoSize = true,
            Location = new Point(0, 2)
        };
        var subtitle = new Label
        {
            Text = "CÔNG TY SƠN ĐÔNG Á  •  Quản lý hồ sơ, hợp đồng, chấm công, lương và quyết định nhân sự",
            AutoSize = true,
            ForeColor = Color.DimGray,
            Location = new Point(2, 38)
        };
        header.Controls.Add(title);
        header.Controls.Add(subtitle);

        _module.DropDownStyle = ComboBoxStyle.DropDownList;
        _module.Width = 260;
        _module.Location = new Point(2, 62);
        _module.DataSource = Modules.Select(x => new ModuleItem(x.Table, x.Caption)).ToList();
        _module.DisplayMember = nameof(ModuleItem.Caption);
        _module.ValueMember = nameof(ModuleItem.Table);
        _module.SelectedValue = _currentTable;
        _module.SelectedValueChanged += (_, _) =>
        {
            if (_module.SelectedValue is string table && table.Length > 0 && table != _currentTable)
            {
                _currentTable = table;
                LoadSelectedTable();
            }
        };

        var refresh = MakeButton("Tải lại", (_, _) => LoadSelectedTable());
        refresh.Location = new Point(278, 60);
        var add = MakeButton("Thêm dòng", (_, _) => AddRow());
        add.Location = new Point(366, 60);
        var delete = MakeButton("Xóa dòng", (_, _) => DeleteSelectedRows());
        delete.Location = new Point(464, 60);
        var save = MakeButton("Lưu thay đổi", (_, _) => SaveChanges());
        save.Location = new Point(562, 60);
        var connection = MakeButton("Kết nối...", (_, _) => EditConnectionString());
        connection.Location = new Point(674, 60);
        header.Controls.AddRange(new Control[] { _module, refresh, add, delete, save, connection });
        root.Controls.Add(header, 0, 0);

        _grid.Dock = DockStyle.Fill;
        _grid.BackgroundColor = Color.White;
        _grid.BorderStyle = BorderStyle.Fixed3D;
        _grid.AllowUserToAddRows = false;
        _grid.AllowUserToDeleteRows = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
        _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        _grid.MultiSelect = true;
        _grid.RowHeadersWidth = 34;
        _grid.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
        _grid.DataError += (_, e) =>
        {
            e.ThrowException = false;
            MessageBox.Show("Giá trị nhập không phù hợp với kiểu dữ liệu của cột. Vui lòng kiểm tra lại.", "Dữ liệu không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        };
        root.Controls.Add(_grid, 0, 1);

        var footer = new StatusStrip { Dock = DockStyle.Fill };
        _footerStatus.Text = "Sẵn sàng";
        footer.Items.Add(_footerStatus);
        root.Controls.Add(footer, 0, 2);
    }

    private static Button MakeButton(string text, EventHandler click)
    {
        var button = new Button { Text = text, Width = 88, Height = 29, FlatStyle = FlatStyle.System };
        button.Click += click;
        return button;
    }

    private void LoadSelectedTable()
    {
        try
        {
            if (_module.SelectedValue is string selected && Modules.Any(x => x.Table == selected))
                _currentTable = selected;

            _connection?.Dispose();
            _connection = Db.CreateConnection();
            _adapter = new SqlDataAdapter($"SELECT * FROM dbo.[{_currentTable}]", _connection)
            {
                MissingSchemaAction = MissingSchemaAction.AddWithKey
            };
            _table = new DataTable(_currentTable);
            _adapter.Fill(_table);
            _commandBuilder = new SqlCommandBuilder(_adapter)
            {
                QuotePrefix = "[",
                QuoteSuffix = "]"
            };
            _grid.DataSource = _table;
            foreach (DataGridViewColumn column in _grid.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.Automatic;
                if (column.Name.StartsWith("Ma", StringComparison.OrdinalIgnoreCase))
                    column.HeaderCell.Style.Font = new Font(_grid.Font, FontStyle.Bold);
            }
            var caption = Modules.First(x => x.Table == _currentTable).Caption;
            _footerStatus.Text = $"Đang xem: {caption}  |  {_table.Rows.Count:N0} dòng  |  CSDL: QuanLyNhanSu_DongA";
        }
        catch (Exception ex)
        {
            _grid.DataSource = null;
            _adapter?.Dispose();
            _commandBuilder?.Dispose();
            _connection?.Dispose();
            _adapter = null;
            _commandBuilder = null;
            _connection = null;
            _footerStatus.Text = "Không kết nối được cơ sở dữ liệu";
            MessageBox.Show(
                "Không tải được dữ liệu. Hãy chạy file QuanLyNhanSu_DongA.sql trong SQL Server Management Studio, " +
                "sau đó kiểm tra Server trong nút 'Kết nối...'.\n\nChi tiết: " + ex.Message,
                "Lỗi kết nối SQL Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void AddRow()
    {
        if (_table is null) return;
        var newRow = _table.NewRow();
        _table.Rows.Add(newRow);
        var rowIndex = _grid.Rows.Count - 1;
        if (rowIndex >= 0)
        {
            _grid.ClearSelection();
            _grid.Rows[rowIndex].Selected = true;
            if (_grid.Columns.Count > 0) _grid.CurrentCell = _grid.Rows[rowIndex].Cells[0];
        }
        _footerStatus.Text = "Đã thêm dòng trống vào lưới. Điền các trường bắt buộc rồi bấm 'Lưu thay đổi'.";
    }

    private void DeleteSelectedRows()
    {
        if (_table is null || _grid.SelectedRows.Count == 0)
        {
            MessageBox.Show("Hãy chọn ít nhất một dòng cần xóa.", "Chưa chọn dòng", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show("Bạn chắc chắn muốn xóa các dòng đã chọn? Các dòng đã lưu sẽ bị xóa trong cơ sở dữ liệu sau khi bấm Lưu thay đổi.",
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

        var indexes = _grid.SelectedRows.Cast<DataGridViewRow>().Select(r => r.Index).Where(i => i >= 0 && i < _table.Rows.Count).Distinct().OrderByDescending(i => i);
        foreach (var index in indexes)
        {
            var row = _table.Rows[index];
            if (row.RowState == DataRowState.Added) _table.Rows.Remove(row);
            else row.Delete();
        }
        _footerStatus.Text = "Đã đánh dấu các dòng để xóa. Bấm 'Lưu thay đổi' để áp dụng.";
    }

    private void SaveChanges()
    {
        if (_table is null || _adapter is null || _commandBuilder is null) return;
        try
        {
            _grid.EndEdit();
            BindingContext[_table]?.EndCurrentEdit();
            _adapter.InsertCommand = _commandBuilder.GetInsertCommand();
            _adapter.UpdateCommand = _commandBuilder.GetUpdateCommand();
            _adapter.DeleteCommand = _commandBuilder.GetDeleteCommand();
            var changes = _adapter.Update(_table);
            _footerStatus.Text = $"Đã lưu {changes:N0} thay đổi vào cơ sở dữ liệu.";
            LoadSelectedTable();
            MessageBox.Show($"Đã lưu {changes:N0} thay đổi.", "Lưu thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Không lưu được dữ liệu. Kiểm tra khóa ngoại, các trường bắt buộc và kiểu dữ liệu.\n\nChi tiết: " + ex.Message,
                "Lỗi khi lưu", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void EditConnectionString()
    {
        const string help = "Nhập tên SQL Server hoặc cả chuỗi kết nối. Nếu nhập tên máy/instance, chuỗi kết nối sẽ được tạo tự động.\nVí dụ: localhost\\SQLEXPRESS hoặc (localdb)\\MSSQLLocalDB";
        var current = Db.ConnectionString;
        var server = ExtractServer(current);
        using var dialog = new ConnectionDialog(server, help);
        if (dialog.ShowDialog(this) != DialogResult.OK) return;
        Db.ConnectionString = dialog.ConnectionString;
        LoadSelectedTable();
    }

    private static string ExtractServer(string connectionString)
    {
        try { return new SqlConnectionStringBuilder(connectionString).DataSource; }
        catch { return "localhost"; }
    }
}

internal sealed class ConnectionDialog : Form
{
    private readonly TextBox _server = new();
    private readonly Label _description = new();
    public string ConnectionString { get; private set; } = string.Empty;

    public ConnectionDialog(string currentServer, string help)
    {
        Text = "Thiết lập kết nối SQL Server";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MinimizeBox = false;
        MaximizeBox = false;
        Width = 520;
        Height = 230;

        var label = new Label { Text = "Server / Instance:", AutoSize = true, Location = new Point(16, 18) };
        _server.SetBounds(16, 42, 470, 28);
        _server.Text = currentServer;
        _description.SetBounds(16, 78, 470, 56);
        _description.Text = help;
        _description.ForeColor = Color.DimGray;
        _description.AutoSize = false;
        _description.MaximumSize = new Size(470, 56);
        var ok = new Button { Text = "Kết nối", DialogResult = DialogResult.OK };
        ok.SetBounds(300, 145, 85, 30);
        var cancel = new Button { Text = "Hủy", DialogResult = DialogResult.Cancel };
        cancel.SetBounds(395, 145, 85, 30);
        ok.Click += (_, _) =>
        {
            var value = _server.Text.Trim();
            if (string.IsNullOrWhiteSpace(value))
            {
                MessageBox.Show("Tên Server không được để trống.");
                DialogResult = DialogResult.None;
                return;
            }
            ConnectionString = new SqlConnectionStringBuilder
            {
                DataSource = value,
                InitialCatalog = "QuanLyNhanSu_DongA",
                IntegratedSecurity = true,
                TrustServerCertificate = true,
                Encrypt = false
            }.ConnectionString;
        };
        Controls.AddRange(new Control[] { label, _server, _description, ok, cancel });
        AcceptButton = ok;
        CancelButton = cancel;
    }
}

internal sealed record ModuleItem(string Table, string Caption);
