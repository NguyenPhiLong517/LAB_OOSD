# Hệ thống quản lý cửa hàng nước giải khát

**Công nghệ:** C# Windows Forms (.NET Framework 4.8), SQL Server / SQL Server LocalDB, mở bằng Visual Studio 2022.

## Chức năng hiện có

- Quản lý nhãn hiệu/loại, nhà cung ứng, nước giải khát, khách hàng và nhân viên: thêm, sửa, xóa, xem danh sách.
- Tra cứu tồn kho.
- Lập đơn đặt hàng theo nhà cung ứng và chi tiết số lượng.
- Ghi nhận phiếu giao hàng; cơ sở dữ liệu kiểm tra tối đa 3 đợt giao trên một đơn và chỉ cộng tồn theo số lượng thực nhận.
- Lập hóa đơn: kiểm tra tồn; khách vãng lai phải nhận đủ hàng ngay; khách quen có thể hẹn giao phần thiếu.
- Có thể ghi nợ khách quen theo hóa đơn và ghi nhận các lần trả nợ.
- Ghi nhận giao hàng theo phiếu hẹn; cập nhật số lượng đã giao, trừ kho và lưu lịch sử giao khách.
- Xem phiếu hẹn, công nợ, lịch sử thu nợ và lịch sử giao khách.

Đây là bản dự án mẫu phục vụ học tập, không có đăng nhập/phân quyền và chưa phải phần mềm triển khai thương mại. Cơ chế tạo phiếu hẹn hiện dùng một ngày hẹn cho mỗi lần lập hóa đơn; dữ liệu cho phép lưu nhiều phiếu hẹn trên một hóa đơn.

## Cách chạy trên máy Windows

1. Cài **Visual Studio 2022** với workload **.NET desktop development** và thành phần **SQL Server Express LocalDB** (hoặc có sẵn SQL Server/SQL Server Express).
2. Mở `QL_CuaHangNuocGiaiKhat.sln` bằng Visual Studio.
3. Mở `QL_CuaHangNuocGiaiKhat.sql` trong SQL Server Management Studio (SSMS), hoặc công cụ truy vấn SQL có kết nối tới ` (localdb)\MSSQLLocalDB `; chạy **toàn bộ file** để tạo database `QL_CuaHangNuocGiaiKhat`, trigger, view, stored procedure và dữ liệu demo.
4. Mặc định chương trình dùng connection string trong `QL_CuaHangNuocGiaiKhat/Database.cs`:

   `Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=QL_CuaHangNuocGiaiKhat;Integrated Security=True;TrustServerCertificate=True;`

   Nếu dùng SQL Server Express, đổi phần `Data Source` thành tên instance trên máy, ví dụ `Data Source=.\SQLEXPRESS;Initial Catalog=QL_CuaHangNuocGiaiKhat;Integrated Security=True;TrustServerCertificate=True;`.
5. Trong Visual Studio, chọn **Build > Build Solution**, sau đó nhấn **F5**. Nhấn “Kiểm tra kết nối CSDL” để kiểm tra kết nối.
6. Dữ liệu mẫu khởi tạo sẵn mã nhân viên `NV01`, nhà cung ứng `NCC01`/`NCC02`, mặt hàng `NGK01`–`NGK03`, khách hàng `KH01` và `KH02`. Có thể bắt đầu thử lập đơn đặt hàng và bán hàng ngay.

## Ghi chú nghiệp vụ

- Mỗi mặt hàng gắn với một nhãn hiệu/loại và một nhà cung ứng.
- Phiếu giao chỉ được ghi cho mặt hàng nằm trong chi tiết đơn đặt hàng đã chọn.
- Trigger cơ sở dữ liệu tự cập nhật tồn kho theo số lượng thực nhận và số lượng giao ngay; không nhập/sửa tồn kho trực tiếp trên màn hình.
- Mã khách quen là loại `KHACH_QUEN`; khách vãng lai là `VANG_LAI`.
- SQL script dùng `CREATE OR ALTER`, cần SQL Server 2016 SP1 trở lên hoặc SQL Server Express LocalDB tương ứng.
