using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace QLCuaHangNuocGiaiKhat
{
    internal sealed class GridPage
    {
        public string Title;
        public string Sql;
        public MasterConfig Master;
        public DataGridView Grid;
        public TabPage Tab;
    }

    public sealed class MainForm : Form
    {
        private readonly TabControl _tabs = new TabControl();
        private readonly List<GridPage> _pages = new List<GridPage>();

        public MainForm()
        {
            Text = "Hệ thống quản lý cửa hàng nước giải khát";
            StartPosition = FormStartPosition.CenterScreen;
            Width = 1280; Height = 780;
            MinimumSize = new Size(1000, 620);
            Font = new Font("Segoe UI", 9F);
            BuildShell();
            BuildPages();
            Load += delegate { ReloadAll(); };
        }

        private void BuildShell()
        {
            Panel header = new Panel { Dock = DockStyle.Top, Height = 72, BackColor = Color.FromArgb(31, 78, 121) };
            Label title = new Label
            {
                Text = "QUẢN LÝ CỬA HÀNG NƯỚC GIẢI KHÁT",
                ForeColor = Color.White, Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                AutoSize = true, Location = new Point(18, 12)
            };
            Label subtitle = new Label
            {
                Text = "Danh mục • Nhập hàng • Bán hàng • Hẹn giao • Công nợ",
                ForeColor = Color.WhiteSmoke, AutoSize = true, Location = new Point(20, 44)
            };
            Button test = new Button { Text = "Kiểm tra kết nối CSDL", Width = 190, Height = 34, Anchor = AnchorStyles.Top | AnchorStyles.Right };
            test.Location = new Point(Width - 240, 20);
            test.Click += delegate { TestConnection(); };
            header.Resize += delegate { test.Left = header.ClientSize.Width - test.Width - 20; };
            header.Controls.Add(title); header.Controls.Add(subtitle); header.Controls.Add(test);
            _tabs.Dock = DockStyle.Fill;
            Controls.Add(_tabs); Controls.Add(header);
        }

        private void BuildPages()
        {
            AddMasterPage(new MasterConfig("Nhãn hiệu / loại", "NHAN_HIEU", "MaLoai", "SELECT MaLoai, TenLoai FROM dbo.NHAN_HIEU ORDER BY MaLoai",
                new FieldSpec("MaLoai", "Mã loại / nhãn hiệu", true),
                new FieldSpec("TenLoai", "Tên loại / nhãn hiệu", true)));

            AddMasterPage(new MasterConfig("Nhà cung ứng", "NHA_CUNG_UNG", "MaNCC", "SELECT MaNCC, TenNCC, DiaChi, SoDienThoai FROM dbo.NHA_CUNG_UNG ORDER BY MaNCC",
                new FieldSpec("MaNCC", "Mã nhà cung ứng", true),
                new FieldSpec("TenNCC", "Tên nhà cung ứng", true),
                new FieldSpec("DiaChi", "Địa chỉ", false),
                new FieldSpec("SoDienThoai", "Số điện thoại", false)));

            AddMasterPage(new MasterConfig("Nước giải khát", "NUOC_GIAI_KHAT", "MaNGK", "SELECT MaNGK, TenNGK, DonViTinh, MaLoai, MaNCC, SoLuongTon, GiaBan FROM dbo.NUOC_GIAI_KHAT ORDER BY MaNGK",
                new FieldSpec("MaNGK", "Mã nước giải khát", true),
                new FieldSpec("TenNGK", "Tên nước giải khát", true),
                new FieldSpec("DonViTinh", "Đơn vị tính", true),
                new FieldSpec("MaLoai", "Mã loại / nhãn hiệu", true),
                new FieldSpec("MaNCC", "Mã nhà cung ứng", true),
                new FieldSpec("GiaBan", "Giá bán", true, "decimal")));

            AddMasterPage(new MasterConfig("Khách hàng", "KHACH_HANG", "MaKH", "SELECT MaKH, TenKH, DiaChi, SoDienThoai, LoaiKhach FROM dbo.KHACH_HANG ORDER BY MaKH",
                new FieldSpec("MaKH", "Mã khách hàng", true),
                new FieldSpec("TenKH", "Tên khách hàng", true),
                new FieldSpec("DiaChi", "Địa chỉ", false),
                new FieldSpec("SoDienThoai", "Số điện thoại", false),
                new FieldSpec("LoaiKhach", "Loại khách", true, "combo", new[] { "KHACH_QUEN", "VANG_LAI" })));

            AddMasterPage(new MasterConfig("Nhân viên", "NHAN_VIEN", "MaNV", "SELECT MaNV, HoTen, SoDienThoai FROM dbo.NHAN_VIEN ORDER BY MaNV",
                new FieldSpec("MaNV", "Mã nhân viên", true),
                new FieldSpec("HoTen", "Họ và tên", true),
                new FieldSpec("SoDienThoai", "Số điện thoại", false)));

            AddDataPage("Tồn kho", "SELECT * FROM dbo.vw_TonKho ORDER BY MaNGK", null);
            AddActionPage("Đơn đặt hàng", "SELECT * FROM dbo.vw_DonDatHang ORDER BY MaDDH DESC", "Lập đơn đặt hàng", delegate { ShowDialogAndReload(new PurchaseOrderDialog()); });
            AddActionPage("Phiếu giao hàng", "SELECT p.MaPGH,p.MaDDH,p.SoDotGiao,p.NgayGiao,p.SoTienPhaiTra,nv.HoTen AS NhanVienLap FROM dbo.PHIEU_GIAO_HANG p JOIN dbo.NHAN_VIEN nv ON nv.MaNV=p.MaNV ORDER BY p.MaPGH DESC", "Ghi nhận phiếu giao", delegate { ShowDialogAndReload(new DeliveryDialog()); });
            AddActionPage("Hóa đơn", "SELECT h.MaHD,h.NgayLap,k.TenKH,h.TongTien,h.TrangThaiThanhToan,nv.HoTen AS NhanVienLap FROM dbo.HOA_DON h JOIN dbo.KHACH_HANG k ON k.MaKH=h.MaKH JOIN dbo.NHAN_VIEN nv ON nv.MaNV=h.MaNV ORDER BY h.MaHD DESC", "Lập hóa đơn", delegate { ShowDialogAndReload(new SalesDialog()); });
            AddActionPage("Phiếu hẹn giao", "SELECT p.MaPH,p.MaHD,k.TenKH,p.NgayHen,p.TrangThai,nv.HoTen AS NhanVienLap FROM dbo.PHIEU_HEN p JOIN dbo.HOA_DON h ON h.MaHD=p.MaHD JOIN dbo.KHACH_HANG k ON k.MaKH=h.MaKH JOIN dbo.NHAN_VIEN nv ON nv.MaNV=p.MaNV ORDER BY p.MaPH DESC", "Ghi nhận giao cho khách", delegate { ShowDialogAndReload(new AppointmentDeliveryDialog()); });
            AddDataPage("Lịch sử giao cho khách", "SELECT g.MaGiao,g.MaPH,g.NgayGiao,k.TenKH,c.MaNGK,n.TenNGK,c.SoLuongGiao,nv.HoTen AS NhanVien FROM dbo.GIAO_HANG_KHACH g JOIN dbo.PHIEU_HEN p ON p.MaPH=g.MaPH JOIN dbo.HOA_DON h ON h.MaHD=p.MaHD JOIN dbo.KHACH_HANG k ON k.MaKH=h.MaKH JOIN dbo.CT_GIAO_HANG_KHACH c ON c.MaGiao=g.MaGiao JOIN dbo.NUOC_GIAI_KHAT n ON n.MaNGK=c.MaNGK JOIN dbo.NHAN_VIEN nv ON nv.MaNV=g.MaNV ORDER BY g.MaGiao DESC", null);
            AddActionPage("Công nợ", "SELECT * FROM dbo.vw_CongNo ORDER BY MaPGN DESC", "Ghi nhận thu nợ", delegate { ShowDialogAndReload(new DebtPaymentDialog()); });
            AddDataPage("Lịch sử thu nợ", "SELECT t.MaTT,t.MaPGN,k.TenKH,t.NgayThanhToan,t.SoTien,nv.HoTen AS NhanVien FROM dbo.THANH_TOAN_NO t JOIN dbo.PHIEU_GHI_NO p ON p.MaPGN=t.MaPGN JOIN dbo.KHACH_HANG k ON k.MaKH=p.MaKH JOIN dbo.NHAN_VIEN nv ON nv.MaNV=t.MaNV ORDER BY t.MaTT DESC", null);
        }

        private void AddMasterPage(MasterConfig config)
        {
            GridPage page = MakePage(config.Title, config.SelectSql, config);
            AddButton(page, "Thêm", delegate { AddMaster(page); });
            AddButton(page, "Sửa", delegate { EditMaster(page); });
            AddButton(page, "Xóa", delegate { DeleteMaster(page); });
            AddRefresh(page);
            _tabs.TabPages.Add(page.Tab); _pages.Add(page);
        }

        private void AddDataPage(string title, string sql, MasterConfig master)
        {
            GridPage page = MakePage(title, sql, master);
            AddRefresh(page);
            _tabs.TabPages.Add(page.Tab); _pages.Add(page);
        }

        private void AddActionPage(string title, string sql, string actionText, Action action)
        {
            GridPage page = MakePage(title, sql, null);
            AddButton(page, actionText, delegate { action(); });
            AddRefresh(page);
            _tabs.TabPages.Add(page.Tab); _pages.Add(page);
        }

        private GridPage MakePage(string title, string sql, MasterConfig master)
        {
            GridPage page = new GridPage { Title = title, Sql = sql, Master = master, Tab = new TabPage(title) };
            Panel body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8) };
            FlowLayoutPanel toolbar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 44, FlowDirection = FlowDirection.LeftToRight, WrapContents = false };
            DataGridView grid = new DataGridView
            {
                Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
                MultiSelect = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
                BackgroundColor = Color.White, RowHeadersVisible = false,
                AutoGenerateColumns = true
            };
            page.Grid = grid;
            body.Controls.Add(grid); body.Controls.Add(toolbar);
            page.Tab.Controls.Add(body);
            page.Tab.Tag = toolbar;
            return page;
        }

        private void AddButton(GridPage page, string text, Action action)
        {
            FlowLayoutPanel toolbar = (FlowLayoutPanel)page.Tab.Tag;
            Button button = new Button { Text = text, AutoSize = true, Height = 31, Padding = new Padding(8, 2, 8, 2), Margin = new Padding(2, 4, 8, 2) };
            button.Click += delegate { try { action(); } catch (Exception ex) { ShowError(ex); } };
            toolbar.Controls.Add(button);
        }

        private void AddRefresh(GridPage page)
        {
            AddButton(page, "Tải lại", delegate { Reload(page); });
        }

        private void Reload(GridPage page)
        {
            try
            {
                page.Grid.DataSource = Database.Query(page.Sql);
                page.Grid.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.DisplayedCells);
            }
            catch (Exception ex)
            {
                page.Grid.DataSource = null;
                ShowError(new Exception("Không tải được dữ liệu ở mục '" + page.Title + "'. Hãy chạy file SQL trước và kiểm tra kết nối.\n\n" + ex.Message));
            }
        }

        private void ReloadAll()
        {
            try
            {
                using (SqlConnection connection = Database.OpenConnection()) { }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chưa kết nối được cơ sở dữ liệu. Hãy chạy file QL_CuaHangNuocGiaiKhat.sql rồi kiểm tra SQL Server LocalDB.\n\n" + ex.Message,
                    "Chưa có kết nối CSDL", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            foreach (GridPage p in _pages) Reload(p);
        }

        private void AddMaster(GridPage page)
        {
            using (MasterDataDialog dialog = new MasterDataDialog(page.Master))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                List<SqlParameter> parameters = new List<SqlParameter>();
                List<string> cols = new List<string>();
                List<string> vals = new List<string>();
                int i = 0;
                foreach (FieldSpec f in page.Master.Fields)
                {
                    cols.Add("[" + f.Name + "]"); vals.Add("@p" + i);
                    parameters.Add(Database.P("@p" + i, dialog.Values[f.Name])); i++;
                }
                string sql = "INSERT INTO dbo.[" + page.Master.Table + "] (" + String.Join(",", cols) + ") VALUES (" + String.Join(",", vals) + ")";
                Database.Execute(sql, parameters.ToArray());
            }
            Reload(page);
        }

        private void EditMaster(GridPage page)
        {
            DataGridViewRow row = SelectedRow(page);
            if (row == null) return;
            Dictionary<string, object> current = new Dictionary<string, object>();
            foreach (FieldSpec f in page.Master.Fields) current[f.Name] = row.Cells[f.Name].Value;
            using (MasterDataDialog dialog = new MasterDataDialog(page.Master, current))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                List<SqlParameter> parameters = new List<SqlParameter>();
                List<string> sets = new List<string>();
                int i = 0;
                foreach (FieldSpec f in page.Master.Fields)
                {
                    if (f.Name == page.Master.Key) continue;
                    sets.Add("[" + f.Name + "]=@p" + i);
                    parameters.Add(Database.P("@p" + i, dialog.Values[f.Name])); i++;
                }
                parameters.Add(Database.P("@key", row.Cells[page.Master.Key].Value));
                string sql = "UPDATE dbo.[" + page.Master.Table + "] SET " + String.Join(",", sets) + " WHERE [" + page.Master.Key + "]=@key";
                Database.Execute(sql, parameters.ToArray());
            }
            Reload(page);
        }

        private void DeleteMaster(GridPage page)
        {
            DataGridViewRow row = SelectedRow(page);
            if (row == null) return;
            string key = Convert.ToString(row.Cells[page.Master.Key].Value);
            if (MessageBox.Show("Bạn có chắc muốn xóa bản ghi " + key + "? Nếu đã được dùng trong giao dịch, hệ thống sẽ không cho xóa.", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            Database.Execute("DELETE FROM dbo.[" + page.Master.Table + "] WHERE [" + page.Master.Key + "] = @key", Database.P("@key", key));
            Reload(page);
        }

        private DataGridViewRow SelectedRow(GridPage page)
        {
            if (page.Grid.SelectedRows.Count == 0)
            {
                MessageBox.Show("Hãy chọn một dòng trước.", "Chưa chọn dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }
            return page.Grid.SelectedRows[0];
        }

        private void ShowDialogAndReload(Form dialog)
        {
            using (dialog)
            {
                if (dialog.ShowDialog(this) == DialogResult.OK) ReloadAll();
            }
        }

        private void TestConnection()
        {
            try
            {
                using (SqlConnection con = Database.OpenConnection())
                    MessageBox.Show("Kết nối SQL Server thành công.\nCơ sở dữ liệu: " + con.Database, "Kết nối thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ReloadAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Chưa kết nối được cơ sở dữ liệu.\n\nKiểm tra SQL Server LocalDB và chạy file QL_CuaHangNuocGiaiKhat.sql.\n\n" + ex.Message, "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowError(Exception ex)
        {
            MessageBox.Show(ex.Message, "Có lỗi xảy ra", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
