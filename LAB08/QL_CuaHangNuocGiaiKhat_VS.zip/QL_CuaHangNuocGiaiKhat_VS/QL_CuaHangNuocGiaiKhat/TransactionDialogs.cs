using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace QLCuaHangNuocGiaiKhat
{
    internal static class DialogTools
    {
        public static void Setup(Form form, string title, int width, int height)
        {
            form.Text = title;
            form.StartPosition = FormStartPosition.CenterParent;
            form.FormBorderStyle = FormBorderStyle.Sizable;
            form.MinimizeBox = false;
            form.Width = width; form.Height = height;
            form.MinimumSize = new Size(width - 50, height - 50);
            form.Font = new Font("Segoe UI", 9F);
        }

        public static Label Label(string text, int x, int y, int width = 150)
        {
            return new Label { Text = text, Location = new Point(x, y), Size = new Size(width, 24), TextAlign = ContentAlignment.MiddleLeft };
        }

        public static ComboBox Combo(string sql, string valueField, string displayField, int x, int y, int width)
        {
            ComboBox combo = new ComboBox { Location = new Point(x, y), Width = width, DropDownStyle = ComboBoxStyle.DropDownList };
            combo.DataSource = Database.Query(sql);
            combo.ValueMember = valueField;
            combo.DisplayMember = displayField;
            if (combo.Items.Count > 0) combo.SelectedIndex = 0;
            return combo;
        }

        public static DateTimePicker Date(int x, int y, DateTime value)
        {
            return new DateTimePicker { Location = new Point(x, y), Width = 160, Format = DateTimePickerFormat.Short, Value = value.Date };
        }

        public static DataGridView LineGrid(int x, int y, int width, int height, params string[] columns)
        {
            DataGridView grid = new DataGridView
            {
                Location = new Point(x, y), Size = new Size(width, height),
                AllowUserToAddRows = true, AllowUserToDeleteRows = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White, RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.CellSelect,
                EditMode = DataGridViewEditMode.EditOnEnter
            };
            foreach (string column in columns)
                grid.Columns.Add(column, column);
            return grid;
        }

        public static List<Dictionary<string, object>> ReadLines(DataGridView grid, string productColumn, string quantityColumn)
        {
            List<Dictionary<string, object>> lines = new List<Dictionary<string, object>>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow) continue;
                string code = Convert.ToString(row.Cells[productColumn].Value).Trim();
                string qtyText = Convert.ToString(row.Cells[quantityColumn].Value).Trim();
                if (String.IsNullOrWhiteSpace(code) && String.IsNullOrWhiteSpace(qtyText)) continue;
                if (String.IsNullOrWhiteSpace(code) || String.IsNullOrWhiteSpace(qtyText))
                    throw new InvalidOperationException("Mỗi dòng chi tiết cần có mã nước giải khát và số lượng.");
                int qty;
                if (!Int32.TryParse(qtyText, out qty) || qty <= 0)
                    throw new InvalidOperationException("Số lượng phải là số nguyên lớn hơn 0.");
                if (!seen.Add(code))
                    throw new InvalidOperationException("Mã nước giải khát " + code + " bị nhập lặp. Hãy gộp số lượng vào một dòng.");
                lines.Add(new Dictionary<string, object> { { "MaNGK", code }, { "SoLuong", qty } });
            }
            if (lines.Count == 0) throw new InvalidOperationException("Hãy nhập ít nhất một dòng mặt hàng.");
            return lines;
        }

        public static object Selected(ComboBox combo)
        {
            if (combo.SelectedValue == null || combo.SelectedValue == DBNull.Value)
                throw new InvalidOperationException("Không có dữ liệu để chọn. Hãy nhập danh mục liên quan trước.");
            return combo.SelectedValue;
        }

        public static void AddSaveCancel(Form form, Action save)
        {
            Button saveButton = new Button { Text = "Lưu giao dịch", Width = 120, Height = 34, Anchor = AnchorStyles.Bottom | AnchorStyles.Right };
            Button cancelButton = new Button { Text = "Hủy", Width = 90, Height = 34, DialogResult = DialogResult.Cancel, Anchor = AnchorStyles.Bottom | AnchorStyles.Right };
            saveButton.Location = new Point(form.ClientSize.Width - 245, form.ClientSize.Height - 72);
            cancelButton.Location = new Point(form.ClientSize.Width - 130, form.ClientSize.Height - 72);
            saveButton.Click += delegate
            {
                try
                {
                    save();
                    form.DialogResult = DialogResult.OK;
                    form.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Không thể lưu giao dịch", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            form.Controls.Add(saveButton); form.Controls.Add(cancelButton);
            form.AcceptButton = saveButton; form.CancelButton = cancelButton;
            form.Resize += delegate
            {
                saveButton.Left = form.ClientSize.Width - 245;
                cancelButton.Left = form.ClientSize.Width - 130;
                saveButton.Top = form.ClientSize.Height - 72;
                cancelButton.Top = form.ClientSize.Height - 72;
            };
        }

        public static decimal ReadDecimal(NumericUpDown control) { return control.Value; }
    }

    internal sealed class PurchaseOrderDialog : Form
    {
        private readonly ComboBox _supplier;
        private readonly ComboBox _employee;
        private readonly DateTimePicker _orderDate;
        private readonly DateTimePicker _expectedDate;
        private readonly DataGridView _lines;

        public PurchaseOrderDialog()
        {
            DialogTools.Setup(this, "Lập đơn đặt hàng", 900, 680);
            Controls.Add(DialogTools.Label("Nhà cung ứng", 18, 16));
            _supplier = DialogTools.Combo("SELECT MaNCC, CONCAT(MaNCC,' - ',TenNCC) AS HienThi FROM dbo.NHA_CUNG_UNG ORDER BY MaNCC", "MaNCC", "HienThi", 18, 40, 360);
            Controls.Add(_supplier);
            Controls.Add(DialogTools.Label("Nhân viên lập", 470, 16));
            _employee = DialogTools.Combo("SELECT MaNV, CONCAT(MaNV,' - ',HoTen) AS HienThi FROM dbo.NHAN_VIEN ORDER BY MaNV", "MaNV", "HienThi", 470, 40, 360);
            Controls.Add(_employee);
            Controls.Add(DialogTools.Label("Ngày đặt", 18, 82));
            _orderDate = DialogTools.Date(18, 106, DateTime.Today); Controls.Add(_orderDate);
            Controls.Add(DialogTools.Label("Ngày nhận dự kiến", 260, 82));
            _expectedDate = DialogTools.Date(260, 106, DateTime.Today.AddDays(3)); Controls.Add(_expectedDate);
            Controls.Add(DialogTools.Label("Chi tiết đơn: nhập mã mặt hàng và số lượng đặt", 18, 148, 500));
            _lines = DialogTools.LineGrid(18, 176, 846, 390, "MaNGK", "SoLuongDat"); Controls.Add(_lines);
            Controls.Add(new Label { Text = "Mã mặt hàng phải thuộc đúng nhà cung ứng đã chọn. Một đơn có thể nhận tối đa 3 đợt.", Location = new Point(18, 572), AutoSize = true, ForeColor = Color.DimGray });
            DialogTools.AddSaveCancel(this, SaveOrder);
        }

        private void SaveOrder()
        {
            if (_expectedDate.Value.Date < _orderDate.Value.Date) throw new InvalidOperationException("Ngày nhận dự kiến không được trước ngày đặt.");
            object supplierId = DialogTools.Selected(_supplier);
            object employeeId = DialogTools.Selected(_employee);
            List<Dictionary<string, object>> lines = DialogTools.ReadLines(_lines, "MaNGK", "SoLuongDat");
            using (SqlConnection con = Database.OpenConnection())
            using (SqlTransaction tx = con.BeginTransaction())
            {
                try
                {
                    int orderId;
                    using (SqlCommand cmd = new SqlCommand("INSERT dbo.DON_DAT_HANG(MaNCC,NgayDat,NgayNhanDuKien,MaNV,TrangThai) OUTPUT INSERTED.MaDDH VALUES(@ncc,@ngay,@du_kien,@nv,N'CHO_GIAO')", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@ncc", supplierId);
                        cmd.Parameters.AddWithValue("@ngay", _orderDate.Value.Date);
                        cmd.Parameters.AddWithValue("@du_kien", _expectedDate.Value.Date);
                        cmd.Parameters.AddWithValue("@nv", employeeId);
                        orderId = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    foreach (Dictionary<string, object> line in lines)
                    {
                        string code = Convert.ToString(line["MaNGK"]);
                        object actualSupplier;
                        using (SqlCommand check = new SqlCommand("SELECT MaNCC FROM dbo.NUOC_GIAI_KHAT WHERE MaNGK=@code", con, tx))
                        {
                            check.Parameters.AddWithValue("@code", code);
                            actualSupplier = check.ExecuteScalar();
                        }
                        if (actualSupplier == null || actualSupplier == DBNull.Value) throw new InvalidOperationException("Không tìm thấy mặt hàng " + code + ".");
                        if (!String.Equals(Convert.ToString(actualSupplier), Convert.ToString(supplierId), StringComparison.OrdinalIgnoreCase))
                            throw new InvalidOperationException("Mặt hàng " + code + " không thuộc nhà cung ứng đã chọn.");
                        using (SqlCommand insert = new SqlCommand("INSERT dbo.CT_DON_DAT_HANG(MaDDH,MaNGK,SoLuongDat) VALUES(@id,@code,@qty)", con, tx))
                        {
                            insert.Parameters.AddWithValue("@id", orderId);
                            insert.Parameters.AddWithValue("@code", code);
                            insert.Parameters.AddWithValue("@qty", line["SoLuong"]);
                            insert.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                    MessageBox.Show("Đã lập đơn đặt hàng số " + orderId + ".", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch { try { tx.Rollback(); } catch { } throw; }
            }
        }
    }

    internal sealed class DeliveryDialog : Form
    {
        private readonly ComboBox _order;
        private readonly ComboBox _employee;
        private readonly DateTimePicker _deliveryDate;
        private readonly NumericUpDown _amount;
        private readonly DataGridView _lines;

        public DeliveryDialog()
        {
            DialogTools.Setup(this, "Ghi nhận phiếu giao hàng", 900, 680);
            Controls.Add(DialogTools.Label("Đơn đặt hàng (chưa đủ 3 đợt)", 18, 16, 250));
            _order = DialogTools.Combo("SELECT d.MaDDH, CONCAT('Đơn #',CONVERT(varchar(12),d.MaDDH),' - ',n.TenNCC,' (đã giao ',CONVERT(varchar(2),COUNT(p.MaPGH)),'/3 đợt)') AS HienThi FROM dbo.DON_DAT_HANG d JOIN dbo.NHA_CUNG_UNG n ON n.MaNCC=d.MaNCC LEFT JOIN dbo.PHIEU_GIAO_HANG p ON p.MaDDH=d.MaDDH GROUP BY d.MaDDH,n.TenNCC HAVING COUNT(p.MaPGH)<3 ORDER BY d.MaDDH DESC", "MaDDH", "HienThi", 18, 40, 420); Controls.Add(_order);
            Controls.Add(DialogTools.Label("Nhân viên lập", 480, 16));
            _employee = DialogTools.Combo("SELECT MaNV, CONCAT(MaNV,' - ',HoTen) AS HienThi FROM dbo.NHAN_VIEN ORDER BY MaNV", "MaNV", "HienThi", 480, 40, 350); Controls.Add(_employee);
            Controls.Add(DialogTools.Label("Ngày giao", 18, 82)); _deliveryDate = DialogTools.Date(18, 106, DateTime.Today); Controls.Add(_deliveryDate);
            Controls.Add(DialogTools.Label("Số tiền phải trả (đợt này)", 260, 82, 200));
            _amount = new NumericUpDown { Location = new Point(260, 106), Width = 200, Minimum = 0, Maximum = 999999999, DecimalPlaces = 2, ThousandsSeparator = true }; Controls.Add(_amount);
            Controls.Add(DialogTools.Label("Chi tiết hàng thực nhận", 18, 148, 300));
            _lines = DialogTools.LineGrid(18, 176, 846, 390, "MaNGK", "SoLuongThucGiao"); Controls.Add(_lines);
            Controls.Add(new Label { Text = "Tồn kho chỉ tăng theo số lượng thực giao đã lưu; mỗi đơn đặt hàng tối đa 3 phiếu giao.", Location = new Point(18, 572), AutoSize = true, ForeColor = Color.DimGray });
            DialogTools.AddSaveCancel(this, SaveDelivery);
        }

        private void SaveDelivery()
        {
            int orderId = Convert.ToInt32(DialogTools.Selected(_order));
            object employeeId = DialogTools.Selected(_employee);
            List<Dictionary<string, object>> lines = DialogTools.ReadLines(_lines, "MaNGK", "SoLuongThucGiao");
            using (SqlConnection con = Database.OpenConnection())
            using (SqlTransaction tx = con.BeginTransaction())
            {
                try
                {
                    int ordinal;
                    using (SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(SoDotGiao),0)+1 FROM dbo.PHIEU_GIAO_HANG WITH (UPDLOCK,HOLDLOCK) WHERE MaDDH=@id", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@id", orderId); ordinal = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    if (ordinal > 3) throw new InvalidOperationException("Đơn đặt hàng này đã nhận đủ 3 đợt giao.");
                    int deliveryId;
                    using (SqlCommand cmd = new SqlCommand("INSERT dbo.PHIEU_GIAO_HANG(MaDDH,SoDotGiao,NgayGiao,SoTienPhaiTra,MaNV) OUTPUT INSERTED.MaPGH VALUES(@order,@ordinal,@date,@amount,@employee)", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@order", orderId); cmd.Parameters.AddWithValue("@ordinal", ordinal);
                        cmd.Parameters.AddWithValue("@date", _deliveryDate.Value.Date); cmd.Parameters.AddWithValue("@amount", _amount.Value);
                        cmd.Parameters.AddWithValue("@employee", employeeId); deliveryId = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    foreach (Dictionary<string, object> line in lines)
                    {
                        string code = Convert.ToString(line["MaNGK"]);
                        using (SqlCommand check = new SqlCommand("SELECT COUNT(*) FROM dbo.CT_DON_DAT_HANG WHERE MaDDH=@order AND MaNGK=@code", con, tx))
                        {
                            check.Parameters.AddWithValue("@order", orderId); check.Parameters.AddWithValue("@code", code);
                            if (Convert.ToInt32(check.ExecuteScalar()) == 0) throw new InvalidOperationException("Mặt hàng " + code + " không nằm trong đơn đặt hàng đã chọn.");
                        }
                        using (SqlCommand insert = new SqlCommand("INSERT dbo.CT_PHIEU_GIAO(MaPGH,MaNGK,SoLuongThucGiao) VALUES(@id,@code,@qty)", con, tx))
                        {
                            insert.Parameters.AddWithValue("@id", deliveryId); insert.Parameters.AddWithValue("@code", code);
                            insert.Parameters.AddWithValue("@qty", line["SoLuong"]); insert.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                    MessageBox.Show("Đã ghi nhận phiếu giao số " + deliveryId + " (đợt " + ordinal + "). Tồn kho đã được cập nhật theo số lượng thực nhận.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch { try { tx.Rollback(); } catch { } throw; }
            }
        }
    }

    internal sealed class SalesDialog : Form
    {
        private readonly ComboBox _customer;
        private readonly ComboBox _employee;
        private readonly DateTimePicker _invoiceDate;
        private readonly DataGridView _lines;
        private readonly CheckBox _scheduleShortage;
        private readonly DateTimePicker _appointmentDate;
        private readonly CheckBox _recordDebt;
        private readonly DateTimePicker _dueDate;
        private readonly TextBox _debtReason;

        public SalesDialog()
        {
            DialogTools.Setup(this, "Lập hóa đơn bán hàng", 940, 760);
            Controls.Add(DialogTools.Label("Khách hàng", 18, 12));
            _customer = DialogTools.Combo("SELECT MaKH, CONCAT(MaKH,' - ',TenKH,' (',LoaiKhach,')') AS HienThi FROM dbo.KHACH_HANG ORDER BY MaKH", "MaKH", "HienThi", 18, 36, 390); Controls.Add(_customer);
            Controls.Add(DialogTools.Label("Nhân viên lập", 480, 12));
            _employee = DialogTools.Combo("SELECT MaNV, CONCAT(MaNV,' - ',HoTen) AS HienThi FROM dbo.NHAN_VIEN ORDER BY MaNV", "MaNV", "HienThi", 480, 36, 400); Controls.Add(_employee);
            Controls.Add(DialogTools.Label("Ngày lập hóa đơn", 18, 75)); _invoiceDate = DialogTools.Date(18, 99, DateTime.Today); Controls.Add(_invoiceDate);
            _scheduleShortage = new CheckBox { Text = "Tạo phiếu hẹn cho phần thiếu (chỉ khách quen)", Checked = true, AutoSize = true, Location = new Point(250, 101) }; Controls.Add(_scheduleShortage);
            Controls.Add(DialogTools.Label("Ngày hẹn giao", 650, 75, 150));
            _appointmentDate = DialogTools.Date(650, 99, DateTime.Today.AddDays(1)); Controls.Add(_appointmentDate);
            _recordDebt = new CheckBox { Text = "Ghi nợ khách quen theo toàn bộ hóa đơn", AutoSize = true, Location = new Point(18, 141) }; Controls.Add(_recordDebt);
            Controls.Add(DialogTools.Label("Ngày dự kiến trả", 390, 135)); _dueDate = DialogTools.Date(390, 159, DateTime.Today.AddDays(7)); Controls.Add(_dueDate);
            Controls.Add(DialogTools.Label("Lý do nợ", 590, 135));
            _debtReason = new TextBox { Location = new Point(590, 159), Width = 290 } ; Controls.Add(_debtReason);
            Controls.Add(DialogTools.Label("Chi tiết bán hàng: nhập mã mặt hàng và số lượng khách yêu cầu", 18, 198, 600));
            _lines = DialogTools.LineGrid(18, 226, 862, 410, "MaNGK", "SoLuongYeuCau"); Controls.Add(_lines);
            Controls.Add(new Label { Text = "Khách vãng lai phải nhận đủ hàng ngay. Với khách quen, lượng giao ngay sẽ trừ kho; phần thiếu được ghi phiếu hẹn.", Location = new Point(18, 642), AutoSize = true, ForeColor = Color.DimGray });
            DialogTools.AddSaveCancel(this, SaveInvoice);
        }

        private void SaveInvoice()
        {
            string customerId = Convert.ToString(DialogTools.Selected(_customer));
            string employeeId = Convert.ToString(DialogTools.Selected(_employee));
            List<Dictionary<string, object>> lines = DialogTools.ReadLines(_lines, "MaNGK", "SoLuongYeuCau");
            using (SqlConnection con = Database.OpenConnection())
            using (SqlTransaction tx = con.BeginTransaction(IsolationLevel.Serializable))
            {
                try
                {
                    string customerType;
                    using (SqlCommand cmd = new SqlCommand("SELECT LoaiKhach FROM dbo.KHACH_HANG WITH (UPDLOCK,HOLDLOCK) WHERE MaKH=@id", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@id", customerId); customerType = Convert.ToString(cmd.ExecuteScalar());
                    }
                    if (String.IsNullOrEmpty(customerType)) throw new InvalidOperationException("Không tìm thấy khách hàng.");
                    if (_recordDebt.Checked && customerType != "KHACH_QUEN") throw new InvalidOperationException("Chỉ khách quen mới được ghi nợ.");

                    List<SaleLine> salesLines = new List<SaleLine>();
                    decimal total = 0m;
                    bool anyShort = false;
                    foreach (Dictionary<string, object> input in lines)
                    {
                        string code = Convert.ToString(input["MaNGK"]);
                        int requested = Convert.ToInt32(input["SoLuong"]);
                        decimal price; int stock;
                        using (SqlCommand cmd = new SqlCommand("SELECT GiaBan,SoLuongTon FROM dbo.NUOC_GIAI_KHAT WITH (UPDLOCK,HOLDLOCK) WHERE MaNGK=@code", con, tx))
                        {
                            cmd.Parameters.AddWithValue("@code", code);
                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (!reader.Read()) throw new InvalidOperationException("Không tìm thấy mặt hàng " + code + ".");
                                price = reader.GetDecimal(0); stock = reader.GetInt32(1);
                            }
                        }
                        if (customerType == "VANG_LAI" && stock < requested)
                            throw new InvalidOperationException("Mặt hàng " + code + " không đủ tồn kho. Khách vãng lai phải nhận đủ hàng ngay; hãy giảm số lượng hoặc kiểm tra kho.");
                        int delivered = Math.Min(stock, requested);
                        int shortage = requested - delivered;
                        if (shortage > 0) anyShort = true;
                        total += price * requested;
                        salesLines.Add(new SaleLine { Code = code, Requested = requested, Delivered = delivered, Shortage = shortage, Price = price });
                    }
                    if (anyShort && customerType == "KHACH_QUEN" && !_scheduleShortage.Checked)
                        throw new InvalidOperationException("Có mặt hàng thiếu tồn. Hãy bật tùy chọn tạo phiếu hẹn để theo dõi phần chưa giao.");
                    if (_recordDebt.Checked && _dueDate.Value.Date < _invoiceDate.Value.Date)
                        throw new InvalidOperationException("Ngày dự kiến trả nợ không được trước ngày lập hóa đơn.");
                    if (_recordDebt.Checked && String.IsNullOrWhiteSpace(_debtReason.Text))
                        throw new InvalidOperationException("Hãy nhập lý do nợ.");
                    if (anyShort && _appointmentDate.Value.Date < _invoiceDate.Value.Date)
                        throw new InvalidOperationException("Ngày hẹn giao không được trước ngày lập hóa đơn.");

                    int invoiceId;
                    string payStatus = _recordDebt.Checked ? "CON_NO" : "DA_THANH_TOAN";
                    using (SqlCommand cmd = new SqlCommand("INSERT dbo.HOA_DON(MaKH,NgayLap,TongTien,TrangThaiThanhToan,MaNV) OUTPUT INSERTED.MaHD VALUES(@kh,@date,@total,@status,@nv)", con, tx))
                    {
                        cmd.Parameters.AddWithValue("@kh", customerId); cmd.Parameters.AddWithValue("@date", _invoiceDate.Value.Date);
                        cmd.Parameters.AddWithValue("@total", total); cmd.Parameters.AddWithValue("@status", payStatus); cmd.Parameters.AddWithValue("@nv", employeeId);
                        invoiceId = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    foreach (SaleLine line in salesLines)
                    {
                        using (SqlCommand cmd = new SqlCommand("INSERT dbo.CT_HOA_DON(MaHD,MaNGK,SoLuongYeuCau,SoLuongGiaoNgay,DonGia) VALUES(@hd,@code,@requested,@delivered,@price)", con, tx))
                        {
                            cmd.Parameters.AddWithValue("@hd", invoiceId); cmd.Parameters.AddWithValue("@code", line.Code);
                            cmd.Parameters.AddWithValue("@requested", line.Requested); cmd.Parameters.AddWithValue("@delivered", line.Delivered); cmd.Parameters.AddWithValue("@price", line.Price);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    List<SaleLine> shortLines = salesLines.Where(x => x.Shortage > 0).ToList();
                    if (shortLines.Count > 0)
                    {
                        int appointmentId;
                        using (SqlCommand cmd = new SqlCommand("INSERT dbo.PHIEU_HEN(MaHD,NgayHen,TrangThai,MaNV) OUTPUT INSERTED.MaPH VALUES(@hd,@date,N'CHO_GIAO',@nv)", con, tx))
                        {
                            cmd.Parameters.AddWithValue("@hd", invoiceId); cmd.Parameters.AddWithValue("@date", _appointmentDate.Value.Date); cmd.Parameters.AddWithValue("@nv", employeeId);
                            appointmentId = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                        foreach (SaleLine line in shortLines)
                        {
                            using (SqlCommand cmd = new SqlCommand("INSERT dbo.CT_PHIEU_HEN(MaPH,MaNGK,SoLuongHen) VALUES(@ph,@code,@qty)", con, tx))
                            {
                                cmd.Parameters.AddWithValue("@ph", appointmentId); cmd.Parameters.AddWithValue("@code", line.Code); cmd.Parameters.AddWithValue("@qty", line.Shortage); cmd.ExecuteNonQuery();
                            }
                        }
                    }
                    if (_recordDebt.Checked)
                    {
                        using (SqlCommand cmd = new SqlCommand("INSERT dbo.PHIEU_GHI_NO(MaKH,MaHD,NgayLap,SoTienNo,NgayDuKienTra,LyDo,MaNV) VALUES(@kh,@hd,@date,@amount,@due,@reason,@nv)", con, tx))
                        {
                            cmd.Parameters.AddWithValue("@kh", customerId); cmd.Parameters.AddWithValue("@hd", invoiceId);
                            cmd.Parameters.AddWithValue("@date", _invoiceDate.Value.Date); cmd.Parameters.AddWithValue("@amount", total);
                            cmd.Parameters.AddWithValue("@due", _dueDate.Value.Date); cmd.Parameters.AddWithValue("@reason", _debtReason.Text.Trim()); cmd.Parameters.AddWithValue("@nv", employeeId);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    tx.Commit();
                    string summary = "Đã lập hóa đơn số " + invoiceId + ". Tổng tiền: " + total.ToString("N0", CultureInfo.CurrentCulture) + " đ.";
                    if (anyShort) summary += "\nPhần chưa giao đã được ghi phiếu hẹn.";
                    if (_recordDebt.Checked) summary += "\nĐã tạo phiếu ghi nợ cho khách quen.";
                    MessageBox.Show(summary, "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch { try { tx.Rollback(); } catch { } throw; }
            }
        }

        private sealed class SaleLine
        {
            public string Code; public int Requested; public int Delivered; public int Shortage; public decimal Price;
        }
    }

    internal sealed class AppointmentDeliveryDialog : Form
    {
        private readonly ComboBox _appointment;
        private readonly ComboBox _item;
        private readonly ComboBox _employee;
        private readonly NumericUpDown _quantity;
        private readonly DateTimePicker _deliveryDate;

        public AppointmentDeliveryDialog()
        {
            DialogTools.Setup(this, "Ghi nhận giao hàng theo phiếu hẹn", 760, 440);
            Controls.Add(DialogTools.Label("Phiếu hẹn còn hàng chưa giao", 18, 18, 250));
            _appointment = DialogTools.Combo(
                "SELECT p.MaPH, CONCAT('Phiếu hẹn #',p.MaPH,' - ',k.TenKH,' - ngày hẹn ',CONVERT(varchar(10),p.NgayHen,103)) AS HienThi " +
                "FROM dbo.PHIEU_HEN p JOIN dbo.HOA_DON h ON h.MaHD=p.MaHD JOIN dbo.KHACH_HANG k ON k.MaKH=h.MaKH " +
                "WHERE EXISTS (SELECT 1 FROM dbo.CT_PHIEU_HEN c WHERE c.MaPH=p.MaPH AND c.SoLuongDaGiao<c.SoLuongHen) ORDER BY p.MaPH DESC",
                "MaPH", "HienThi", 18, 42, 700);
            Controls.Add(_appointment);

            Controls.Add(DialogTools.Label("Mặt hàng còn phải giao trên phiếu hẹn", 18, 92, 300));
            _item = new ComboBox { Location = new Point(18, 116), Width = 700, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(_item);
            Controls.Add(DialogTools.Label("Số lượng giao lần này", 18, 166));
            _quantity = new NumericUpDown { Location = new Point(18, 190), Width = 250, Minimum = 1, Maximum = 100000, DecimalPlaces = 0, ThousandsSeparator = true };
            Controls.Add(_quantity);
            Controls.Add(DialogTools.Label("Nhân viên ghi nhận", 360, 166));
            _employee = DialogTools.Combo("SELECT MaNV, CONCAT(MaNV,' - ',HoTen) AS HienThi FROM dbo.NHAN_VIEN ORDER BY MaNV", "MaNV", "HienThi", 360, 190, 300);
            Controls.Add(_employee);
            Controls.Add(DialogTools.Label("Ngày giao thực tế", 18, 226));
            _deliveryDate = DialogTools.Date(18, 250, DateTime.Today); Controls.Add(_deliveryDate);
            Controls.Add(new Label { Text = "Lần giao này sẽ ghi lịch sử, trừ tồn kho và cập nhật số lượng đã giao trên phiếu hẹn.", Location = new Point(18, 290), AutoSize = true, ForeColor = Color.DimGray });
            _appointment.SelectedIndexChanged += delegate { LoadAppointmentItems(); };
            LoadAppointmentItems();
            DialogTools.AddSaveCancel(this, SaveDelivery);
        }

        private void LoadAppointmentItems()
        {
            int appointmentId;
            if (_appointment.SelectedValue == null || !Int32.TryParse(Convert.ToString(_appointment.SelectedValue), out appointmentId))
            {
                _item.DataSource = null;
                return;
            }
            DataTable items = Database.Query(
                "SELECT c.MaNGK, CONCAT(c.MaNGK,' - ',n.TenNGK,' (còn hẹn ',CONVERT(varchar(12),c.SoLuongHen-c.SoLuongDaGiao),')') AS HienThi " +
                "FROM dbo.CT_PHIEU_HEN c JOIN dbo.NUOC_GIAI_KHAT n ON n.MaNGK=c.MaNGK " +
                "WHERE c.MaPH=@id AND c.SoLuongDaGiao<c.SoLuongHen ORDER BY c.MaNGK",
                Database.P("@id", appointmentId));
            _item.DataSource = items;
            _item.ValueMember = "MaNGK";
            _item.DisplayMember = "HienThi";
            if (_item.Items.Count > 0) _item.SelectedIndex = 0;
        }

        private void SaveDelivery()
        {
            int appointmentId = Convert.ToInt32(DialogTools.Selected(_appointment));
            string itemCode = Convert.ToString(DialogTools.Selected(_item));
            string employeeId = Convert.ToString(DialogTools.Selected(_employee));
            using (SqlConnection con = Database.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("dbo.sp_GhiNhanGiaoHangHen", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaPH", appointmentId);
                cmd.Parameters.AddWithValue("@MaNGK", itemCode);
                cmd.Parameters.AddWithValue("@SoLuongGiaoThem", Convert.ToInt32(_quantity.Value));
                cmd.Parameters.AddWithValue("@NgayGiao", _deliveryDate.Value.Date);
                cmd.Parameters.AddWithValue("@MaNV", employeeId);
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Đã ghi nhận giao hàng cho phiếu hẹn. Nếu đã giao đủ các mặt hàng, phiếu hẹn được cập nhật trạng thái hoàn tất.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }

    internal sealed class DebtPaymentDialog : Form
    {
        private readonly ComboBox _debt;
        private readonly ComboBox _employee;
        private readonly DateTimePicker _date;
        private readonly NumericUpDown _amount;

        public DebtPaymentDialog()
        {
            DialogTools.Setup(this, "Ghi nhận thanh toán nợ", 720, 390);
            Controls.Add(DialogTools.Label("Phiếu ghi nợ còn số dư", 18, 20, 240));
            _debt = DialogTools.Combo("SELECT p.MaPGN, CONCAT('Phiếu #',p.MaPGN,' - ',k.TenKH,' - còn ',CONVERT(varchar(40),CAST(p.SoTienNo-p.SoTienDaTra AS money),1),' đ') AS HienThi FROM dbo.PHIEU_GHI_NO p JOIN dbo.KHACH_HANG k ON k.MaKH=p.MaKH WHERE p.SoTienDaTra < p.SoTienNo ORDER BY p.MaPGN", "MaPGN", "HienThi", 18, 44, 640); Controls.Add(_debt);
            Controls.Add(DialogTools.Label("Nhân viên ghi nhận", 18, 90));
            _employee = DialogTools.Combo("SELECT MaNV, CONCAT(MaNV,' - ',HoTen) AS HienThi FROM dbo.NHAN_VIEN ORDER BY MaNV", "MaNV", "HienThi", 18, 114, 300); Controls.Add(_employee);
            Controls.Add(DialogTools.Label("Ngày thanh toán", 370, 90)); _date = DialogTools.Date(370, 114, DateTime.Today); Controls.Add(_date);
            Controls.Add(DialogTools.Label("Số tiền nhận được", 18, 160));
            _amount = new NumericUpDown { Location = new Point(18, 184), Width = 300, Minimum = 0.01M, Maximum = 999999999, DecimalPlaces = 2, ThousandsSeparator = true }; Controls.Add(_amount);
            Controls.Add(new Label { Text = "Hệ thống kiểm tra số tiền thu không vượt quá số nợ còn lại.", Location = new Point(18, 235), AutoSize = true, ForeColor = Color.DimGray });
            DialogTools.AddSaveCancel(this, SavePayment);
        }

        private void SavePayment()
        {
            int debtId = Convert.ToInt32(DialogTools.Selected(_debt));
            string employeeId = Convert.ToString(DialogTools.Selected(_employee));
            using (SqlConnection con = Database.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("dbo.sp_GhiNhanThanhToanNo", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaPGN", debtId);
                cmd.Parameters.AddWithValue("@NgayThanhToan", _date.Value.Date);
                cmd.Parameters.AddWithValue("@SoTien", _amount.Value);
                cmd.Parameters.AddWithValue("@MaNV", employeeId);
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Đã ghi nhận thanh toán nợ.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
