using System;
using System.Data;
using System.Data.SqlClient;

namespace QLCuaHangNuocGiaiKhat
{
    internal static class Database
    {
        // Mac dinh dung SQL Server LocalDB di kem Visual Studio. Neu dung SQL Server Express/Server rieng,
        // sua gia tri Server trong connection string nay.
        public static string ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=QL_CuaHangNuocGiaiKhat;Integrated Security=True;TrustServerCertificate=True;";

        public static SqlConnection OpenConnection()
        {
            SqlConnection connection = new SqlConnection(ConnectionString);
            connection.Open();
            return connection;
        }

        public static DataTable Query(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = OpenConnection())
            using (SqlCommand command = new SqlCommand(sql, connection))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                if (parameters != null) command.Parameters.AddRange(parameters);
                DataTable table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }

        public static int Execute(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = OpenConnection())
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null) command.Parameters.AddRange(parameters);
                return command.ExecuteNonQuery();
            }
        }

        public static object Scalar(string sql, params SqlParameter[] parameters)
        {
            using (SqlConnection connection = OpenConnection())
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                if (parameters != null) command.Parameters.AddRange(parameters);
                return command.ExecuteScalar();
            }
        }

        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value == null ? DBNull.Value : value);
        }

        public static void FillCombo(System.Windows.Forms.ComboBox combo, string sql, string valueField, string displayField)
        {
            DataTable table = Query(sql);
            combo.DataSource = table;
            combo.ValueMember = valueField;
            combo.DisplayMember = displayField;
            combo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        }
    }
}
