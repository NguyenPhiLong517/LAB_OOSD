using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace QLCuaHangNuocGiaiKhat
{
    internal sealed class FieldSpec
    {
        public string Name { get; private set; }
        public string Label { get; private set; }
        public bool Required { get; private set; }
        public string Kind { get; private set; }
        public string[] Choices { get; private set; }

        public FieldSpec(string name, string label, bool required, string kind = "text", string[] choices = null)
        {
            Name = name; Label = label; Required = required; Kind = kind; Choices = choices;
        }
    }

    internal sealed class MasterConfig
    {
        public string Title { get; private set; }
        public string Table { get; private set; }
        public string Key { get; private set; }
        public List<FieldSpec> Fields { get; private set; }
        public string SelectSql { get; private set; }

        public MasterConfig(string title, string table, string key, string selectSql, params FieldSpec[] fields)
        {
            Title = title; Table = table; Key = key; SelectSql = selectSql;
            Fields = new List<FieldSpec>(fields);
        }
    }

    internal sealed class MasterDataDialog : Form
    {
        private readonly MasterConfig _config;
        private readonly bool _editing;
        private readonly Dictionary<string, Control> _controls = new Dictionary<string, Control>();
        public Dictionary<string, object> Values { get; private set; }

        public MasterDataDialog(MasterConfig config, Dictionary<string, object> currentValues = null)
        {
            _config = config;
            _editing = currentValues != null;
            Values = new Dictionary<string, object>();
            Text = (_editing ? "Cập nhật " : "Thêm ") + config.Title;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false;
            Width = 540;
            Height = Math.Max(300, 115 + config.Fields.Count * 47);
            Font = new Font("Segoe UI", 9F);

            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.Padding = new Padding(14);
            layout.ColumnCount = 2;
            layout.RowCount = config.Fields.Count + 1;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 165));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < config.Fields.Count; i++) layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));

            int row = 0;
            foreach (FieldSpec field in config.Fields)
            {
                Label label = new Label();
                label.Text = field.Label + (field.Required ? " *" : "");
                label.TextAlign = ContentAlignment.MiddleLeft;
                label.Dock = DockStyle.Fill;
                layout.Controls.Add(label, 0, row);

                Control control;
                if (field.Kind == "combo")
                {
                    ComboBox combo = new ComboBox();
                    combo.DropDownStyle = ComboBoxStyle.DropDownList;
                    if (field.Choices != null) combo.Items.AddRange(field.Choices);
                    if (combo.Items.Count > 0) combo.SelectedIndex = 0;
                    control = combo;
                }
                else
                {
                    TextBox textBox = new TextBox();
                    textBox.Dock = DockStyle.Fill;
                    control = textBox;
                }
                control.Dock = DockStyle.Fill;
                if (field.Name == config.Key && _editing) control.Enabled = false;
                if (currentValues != null && currentValues.ContainsKey(field.Name))
                {
                    string val = Convert.ToString(currentValues[field.Name], CultureInfo.CurrentCulture);
                    ComboBox cb = control as ComboBox;
                    if (cb != null && cb.Items.Contains(val)) cb.SelectedItem = val;
                    else if (control is TextBox) ((TextBox)control).Text = val;
                }
                _controls[field.Name] = control;
                layout.Controls.Add(control, 1, row);
                row++;
            }

            FlowLayoutPanel buttons = new FlowLayoutPanel();
            buttons.FlowDirection = FlowDirection.RightToLeft;
            buttons.Dock = DockStyle.Fill;
            Button save = new Button { Text = "Lưu", Width = 95, Height = 30, DialogResult = DialogResult.None };
            Button cancel = new Button { Text = "Hủy", Width = 95, Height = 30, DialogResult = DialogResult.Cancel };
            save.Click += SaveClicked;
            buttons.Controls.Add(save); buttons.Controls.Add(cancel);
            layout.Controls.Add(buttons, 0, row); layout.SetColumnSpan(buttons, 2);
            Controls.Add(layout);
            AcceptButton = save; CancelButton = cancel;
        }

        private void SaveClicked(object sender, EventArgs e)
        {
            Dictionary<string, object> temp = new Dictionary<string, object>();
            foreach (FieldSpec field in _config.Fields)
            {
                Control control = _controls[field.Name];
                string text;
                ComboBox cb = control as ComboBox;
                if (cb != null) text = cb.SelectedItem == null ? "" : Convert.ToString(cb.SelectedItem);
                else text = control.Text == null ? "" : control.Text.Trim();

                if (field.Required && String.IsNullOrWhiteSpace(text))
                {
                    MessageBox.Show("Vui lòng nhập " + field.Label + ".", "Thiếu thông tin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    control.Focus(); return;
                }
                if (String.IsNullOrWhiteSpace(text)) temp[field.Name] = DBNull.Value;
                else if (field.Kind == "decimal")
                {
                    decimal value;
                    if (!Decimal.TryParse(text, NumberStyles.Number, CultureInfo.CurrentCulture, out value) &&
                        !Decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out value))
                    {
                        MessageBox.Show(field.Label + " phải là số hợp lệ.", "Dữ liệu không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        control.Focus(); return;
                    }
                    if (value < 0)
                    {
                        MessageBox.Show(field.Label + " không được âm.", "Dữ liệu không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        control.Focus(); return;
                    }
                    temp[field.Name] = value;
                }
                else temp[field.Name] = text;
            }
            Values = temp;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}
