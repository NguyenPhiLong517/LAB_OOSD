# Khung giao diện WinForms - Quản lý hồ sơ bệnh án

## 1. Công nghệ
- Visual Studio 2022
- C# Windows Forms App (.NET Framework 4.7.2)
- Giao diện được tạo trực tiếp bằng code C# (không cần các file Designer.cs)
- Chưa kết nối SQL Server; các Form dùng dữ liệu mẫu trong bộ nhớ để bạn làm và kiểm tra giao diện trước.

## 2. Cách mở và chạy project có sẵn
1. Giải nén file ZIP vào một thư mục dễ tìm, ví dụ `D:\Bai5\`.
2. Mở Visual Studio 2022.
3. Chọn **Open a project or solution**.
4. Mở file `QuanLyHoSoBenhAnWinForms.sln` trong thư mục đã giải nén.
5. Nếu Visual Studio hỏi cài workload, vào **Visual Studio Installer > Modify** và cài workload **.NET desktop development**.
6. Nếu không có target framework 4.7.2, cài **.NET Framework 4.7.2 Developer Pack** rồi mở lại solution.
7. Trong Solution Explorer, nhấp phải project `QuanLyHoSoBenhAnWinForms` > **Set as Startup Project**.
8. Nhấn **F5** hoặc bấm nút Start để chạy.

## 3. Các giao diện đã có
- `FrmMain`: trang chủ, menu điều hướng và các thẻ tổng quan.
- `FrmBenhNhan`: thông tin hành chính bệnh nhân.
- `FrmHoSoBenhAn`: cấp/quản lý hồ sơ bệnh án.
- `FrmTraCuuHoSo`: tra cứu theo mã hồ sơ, mã bệnh nhân, họ tên hoặc CCCD.
- `FrmLichKham`: lịch khám sức khỏe định kỳ.
- `FrmKhamBenh`: ghi nhận triệu chứng, chẩn đoán và trạng thái khám.
- `FrmXetNghiem`: chỉ định/kết quả xét nghiệm.
- `FrmToaThuoc`: thuốc kê đơn và cách dùng.
- `FrmThanhToan`: hóa đơn viện phí và trạng thái thanh toán.
- `FrmThongKe`: lọc báo cáo theo ngày và xuất CSV minh họa.

## 4. Cấu trúc code
- `Program.cs`: điểm bắt đầu của ứng dụng.
- `UI/FrmMain.cs`: cửa sổ chính và điều hướng.
- `UI/FieldSpec.cs`: cấu hình trường nhập liệu.
- `UI/FrmCrudBase.cs`: form dùng chung, tạo ô nhập, nút thao tác và DataGridView.
- `UI/ModuleCatalog.cs`: tên trường và dữ liệu mẫu của từng nghiệp vụ.
- `UI/ModuleForms.cs`: các Form nghiệp vụ kế thừa form dùng chung.
- `UI/FrmTraCuuHoSo.cs`: màn hình tra cứu.
- `UI/FrmThongKe.cs`: màn hình báo cáo.

## 5. Thử các nút trên giao diện
- `FrmBenhNhan`: đọc, thêm, sửa, xóa dữ liệu thật trong `dbo.BenhNhan` trên SQL Server.
- Các Form nghiệp vụ khác: hiện vẫn dùng dữ liệu mẫu trong bộ nhớ. Khi tắt chương trình, thay đổi trên các Form đó sẽ mất.
- **Thêm mới**: xóa trắng các ô, chuyển sang chế độ thêm.
- **Lưu dữ liệu**: đối với Bệnh nhân sẽ INSERT/UPDATE SQL; các Form còn lại đang cập nhật dữ liệu mẫu.
- **Xóa bản ghi**: đối với Bệnh nhân sẽ DELETE SQL và có thể bị SQL Server từ chối nếu bản ghi đã được bảng khác tham chiếu.
- **Tìm kiếm**: lọc các dòng đang hiển thị.
- `FrmThongKe` có dữ liệu báo cáo giả lập và chức năng xuất CSV.

## 6. Kết nối SQL Server (đã tích hợp thử cho màn hình Bệnh nhân)
1. Chạy script `QuanLyHoSoBenhAn.sql` bằng SQL Server Management Studio để tạo database và các bảng. Lưu ý: script dùng để khởi tạo môi trường thử nghiệm và có lệnh DROP TABLE; chạy lại sẽ xóa dữ liệu bảng hiện có.
2. `App.config` đã có connection string mặc định cho LocalDB. Sửa `Data Source` để trùng instance SQL Server thực tế trên máy bạn.
3. `Data/Db.cs` tạo kết nối ADO.NET. Màn hình `FrmBenhNhan` đã được nối thử tới `dbo.BenhNhan`: khi mở màn hình, dữ liệu được đọc từ SQL; thêm/sửa/xóa thực hiện trên database thật. Các màn hình nghiệp vụ khác vẫn đang dùng dữ liệu mẫu để nối lần lượt sau.
4. Nếu đang dùng SQL Server Express với instance `SQLEXPRESS`, đổi chuỗi kết nối thành dạng:

```xml
<add name="QuanLyHoSoBenhAn"
     connectionString="Data Source=.\SQLEXPRESS;Initial Catalog=QuanLyHoSoBenhAn;Integrated Security=True;Connect Timeout=30"
     providerName="System.Data.SqlClient" />
```

5. Project tham chiếu `System.Configuration`; không cần cài package NuGet thêm cho `System.Data.SqlClient` trên .NET Framework 4.7.2.

Với LocalDB, chuỗi mặc định:

```xml
<connectionStrings>
  <add name="QuanLyHoSoBenhAn"
       connectionString="Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=QuanLyHoSoBenhAn;Integrated Security=True;Connect Timeout=30"
       providerName="System.Data.SqlClient" />
</connectionStrings>
```

Nếu bạn cài SQL Server Express với tên instance như `SQLEXPRESS`, hãy đổi `Data Source` theo máy của bạn. `Data Source` phải trùng tên instance mà bạn dùng để chạy script trong SSMS.


**Đã sửa lỗi CS0051:** constructor của `FrmCrudBase` dùng `internal` để phù hợp mức truy cập của `ModuleConfig` (internal).
