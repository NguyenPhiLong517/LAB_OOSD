using System.Windows.Forms;

namespace QuanLyHoSoBenhAnWinForms.UI
{
    public sealed class FrmTraCuuHoSo : FrmCrudBase
    {
        public FrmTraCuuHoSo() : base(ModuleCatalog.TraCuuHoSo())
        {
            ToolTip tip = new ToolTip();
            tip.SetToolTip(this, "Nhập từ khóa ở ô Từ khóa rồi bấm Tìm kiếm để lọc dữ liệu mẫu.");
        }
    }
}
