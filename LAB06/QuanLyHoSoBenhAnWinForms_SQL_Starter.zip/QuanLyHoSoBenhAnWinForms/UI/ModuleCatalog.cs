namespace QuanLyHoSoBenhAnWinForms.UI
{
    internal static class ModuleCatalog
    {
        public static ModuleConfig BenhNhan()
        {
            return new ModuleConfig
            {
                Title = "QUẢN LÝ BỆNH NHÂN",
                Description = "Dữ liệu lấy trực tiếp từ SQL Server: dbo.BenhNhan.",
                DbTableName = "BenhNhan",
                KeyFields = new[] { "MaBenhNhan" },
                Fields = new[]
                {
                    new FieldSpec("MaBenhNhan", "Mã bệnh nhân", "text", true),
                    new FieldSpec("HoTen", "Họ và tên", "text", true),
                    new FieldSpec("NgaySinh", "Ngày sinh", "date", true),
                    new FieldSpec("GioiTinh", "Giới tính", "combo", false, "Nam", "Nữ", "Khác"),
                    new FieldSpec("SoDienThoai", "Số điện thoại", "text", true),
                    new FieldSpec("DiaChi", "Địa chỉ", "text", true),
                    new FieldSpec("SoCMND", "CCCD/CMND", "text", true),
                    new FieldSpec("SoTheBHYT", "Số thẻ BHYT", "text")
                },
                SampleRows = new[]
                {
                    new[] { "BN0001", "Nguyễn Văn An", "15/03/1995", "Nam", "0900000001", "TP. Hồ Chí Minh", "079000000001", "BHYT0001" },
                    new[] { "BN0002", "Trần Thị Bình", "21/08/1988", "Nữ", "0900000002", "Bình Dương", "079000000002", "BHYT0002" }
                }
            };
        }

        public static ModuleConfig HoSoBenhAn()
        {
            return new ModuleConfig
            {
                Title = "QUẢN LÝ HỒ SƠ BỆNH ÁN",
                Description = "Cấp, theo dõi trạng thái và lưu trữ hồ sơ bệnh án tổng quát.",
                Fields = new[]
                {
                    new FieldSpec("MaHoSo", "Mã hồ sơ", "text", true),
                    new FieldSpec("MaBenhNhan", "Mã bệnh nhân", "text", true),
                    new FieldSpec("NgayTao", "Ngày tạo", "date", true),
                    new FieldSpec("TrangThai", "Trạng thái hồ sơ", "combo", true, "Mới", "Đang theo dõi", "Đã đóng/Lưu trữ", "Đã khóa"),
                    new FieldSpec("TienSuBenh", "Tiền sử bệnh", "memo"),
                    new FieldSpec("GhiChu", "Ghi chú", "memo")
                },
                SampleRows = new[]
                {
                    new[] { "HS0001", "BN0001", "10/10/2026", "Đang theo dõi", "Dị ứng thời tiết (khai báo mẫu)", "Hồ sơ mẫu" },
                    new[] { "HS0002", "BN0002", "12/10/2026", "Mới", "Chưa ghi nhận", "Hồ sơ mẫu" }
                }
            };
        }

        public static ModuleConfig LichKham()
        {
            return new ModuleConfig
            {
                Title = "LỊCH KHÁM SỨC KHỎE ĐỊNH KỲ",
                Description = "Tiếp nhận yêu cầu, xác nhận hoặc hủy lịch khám định kỳ.",
                Fields = new[]
                {
                    new FieldSpec("MaLichHen", "Mã lịch hẹn", "text", true),
                    new FieldSpec("MaHoSo", "Mã hồ sơ", "text", true),
                    new FieldSpec("MaNhanVien", "Mã bác sĩ/nhân viên", "text"),
                    new FieldSpec("NgayHen", "Ngày giờ hẹn", "datetime", true),
                    new FieldSpec("NoiDungHen", "Nội dung hẹn", "memo"),
                    new FieldSpec("TrangThai", "Trạng thái", "combo", true, "Mới đặt", "Đã xác nhận", "Đã khám", "Đã hủy")
                },
                SampleRows = new[]
                {
                    new[] { "LH0001", "HS0001", "NV0001", "25/10/2026 09:00", "Khám sức khỏe định kỳ quý", "Đã xác nhận" },
                    new[] { "LH0002", "HS0002", "NV0002", "29/10/2026 14:30", "Tái khám định kỳ", "Mới đặt" }
                }
            };
        }

        public static ModuleConfig KhamBenh()
        {
            return new ModuleConfig
            {
                Title = "KHÁM BỆNH",
                Description = "Ghi nhận triệu chứng, chẩn đoán và trạng thái lượt khám.",
                Fields = new[]
                {
                    new FieldSpec("MaPhieuKham", "Mã phiếu khám", "text", true),
                    new FieldSpec("MaHoSo", "Mã hồ sơ", "text", true),
                    new FieldSpec("MaNhanVien", "Mã bác sĩ", "text", true),
                    new FieldSpec("NgayKham", "Ngày khám", "datetime", true),
                    new FieldSpec("TrieuChung", "Triệu chứng", "memo", true),
                    new FieldSpec("ChanDoan", "Chẩn đoán", "memo"),
                    new FieldSpec("TrangThai", "Trạng thái", "combo", true, "Chờ khám", "Đang khám", "Chờ xét nghiệm", "Chờ thanh toán", "Đã hoàn tất", "Đã hủy"),
                    new FieldSpec("LoiDuyenBao", "Lời dặn / ghi chú", "memo")
                },
                SampleRows = new[]
                {
                    new[] { "PK0001", "HS0001", "NV0001", "17/10/2026 08:30", "Đau đầu, mệt mỏi (dữ liệu mẫu)", "Theo dõi và xét nghiệm", "Đang khám", "Uống đủ nước, tái khám khi cần" },
                    new[] { "PK0002", "HS0002", "NV0002", "16/10/2026 10:15", "Khám sức khỏe định kỳ", "Chưa phát hiện bất thường", "Chờ thanh toán", "Lưu kết quả vào hồ sơ" }
                }
            };
        }

        public static ModuleConfig XetNghiem()
        {
            return new ModuleConfig
            {
                Title = "XÉT NGHIỆM",
                Description = "Theo dõi chỉ định, quá trình thực hiện và kết quả xét nghiệm.",
                Fields = new[]
                {
                    new FieldSpec("MaChiTietXN", "Mã chi tiết xét nghiệm", "text", true),
                    new FieldSpec("MaPhieuKham", "Mã phiếu khám", "text", true),
                    new FieldSpec("MaLoaiXN", "Mã loại xét nghiệm", "text", true),
                    new FieldSpec("KetQua", "Kết quả", "memo"),
                    new FieldSpec("NgayThucHien", "Ngày thực hiện", "datetime"),
                    new FieldSpec("GhiChuDanhGia", "Ghi chú đánh giá", "memo"),
                    new FieldSpec("TrangThai", "Trạng thái", "combo", true, "Chờ thực hiện", "Đang thực hiện", "Chờ duyệt", "Đã hoàn thành", "Hủy mẫu")
                },
                SampleRows = new[]
                {
                    new[] { "XN0001", "PK0001", "XN_MAU", "Chờ cập nhật kết quả", "17/10/2026 08:30", "Dữ liệu minh họa, không phải kết quả y tế thật", "Chờ thực hiện" },
                    new[] { "XN0002", "PK0002", "XN_TONG", "Bình thường (mẫu giao diện)", "16/10/2026 10:15", "Kết quả giả lập để thử giao diện", "Đã hoàn thành" }
                }
            };
        }

        public static ModuleConfig ToaThuoc()
        {
            return new ModuleConfig
            {
                Title = "LẬP TOA THUỐC",
                Description = "Lập danh sách thuốc kê đơn và hướng dẫn sử dụng theo phiếu khám.",
                Fields = new[]
                {
                    new FieldSpec("MaPhieuKham", "Mã phiếu khám", "text", true),
                    new FieldSpec("MaThuoc", "Mã thuốc", "text", true),
                    new FieldSpec("SoLuong", "Số lượng", "number", true),
                    new FieldSpec("LieuDung", "Liều dùng", "text", true),
                    new FieldSpec("CachDung", "Cách dùng", "memo", true),
                    new FieldSpec("DonGiaThoiDiem", "Đơn giá tại thời điểm kê", "money", true)
                },
                SampleRows = new[]
                {
                    new[] { "PK0001", "TH0001", "10", "1 viên/lần", "Dùng theo hướng dẫn của bác sĩ", "5000" },
                    new[] { "PK0002", "TH0002", "6", "1 viên/lần", "Dữ liệu minh họa; không dùng làm chỉ định điều trị", "12000" }
                }
            };
        }

        public static ModuleConfig ThanhToan()
        {
            return new ModuleConfig
            {
                Title = "THANH TOÁN VÀ XUẤT VIỆN",
                Description = "Tổng hợp viện phí, ghi nhận giao dịch và xác nhận hoàn tất thanh toán.",
                Fields = new[]
                {
                    new FieldSpec("MaHoaDon", "Mã hóa đơn", "text", true),
                    new FieldSpec("MaPhieuKham", "Mã phiếu khám", "text"),
                    new FieldSpec("MaHoSo", "Mã hồ sơ", "text", true),
                    new FieldSpec("MaNhanVienThuNgan", "Mã thu ngân", "text", true),
                    new FieldSpec("NgayLap", "Ngày lập", "datetime", true),
                    new FieldSpec("LoaiHoaDon", "Loại hóa đơn", "combo", true, "Lệ phí mở hồ sơ", "Phí định kỳ", "Viện phí"),
                    new FieldSpec("TienLePhi", "Lệ phí", "money", true),
                    new FieldSpec("TienKham", "Tiền khám", "money", true),
                    new FieldSpec("TienXetNghiem", "Tiền xét nghiệm", "money", true),
                    new FieldSpec("TienThuoc", "Tiền thuốc", "money", true),
                    new FieldSpec("TienBHYTChiTra", "BHYT chi trả", "money", true),
                    new FieldSpec("TrangThaiThanhToan", "Trạng thái thanh toán", "combo", true, "Chưa thanh toán", "Thanh toán một phần", "Đã thanh toán", "Đã hủy")
                },
                SampleRows = new[]
                {
                    new[] { "HD0001", "PK0001", "HS0001", "NV0003", "17/10/2026 08:30", "Viện phí", "0", "100000", "150000", "50000", "0", "Chưa thanh toán" },
                    new[] { "HD0002", "PK0002", "HS0002", "NV0003", "16/10/2026 10:15", "Phí định kỳ", "0", "0", "0", "0", "0", "Đã thanh toán" }
                }
            };
        }

        public static ModuleConfig TraCuuHoSo()
        {
            return new ModuleConfig
            {
                Title = "TRA CỨU HỒ SƠ BỆNH ÁN",
                Description = "Tìm hồ sơ theo mã hồ sơ, mã bệnh nhân, họ tên hoặc CCCD/CMND.",
                AllowEdit = false,
                SearchPlaceholder = "Nhập mã hồ sơ, mã bệnh nhân, họ tên hoặc CCCD...",
                Fields = new[]
                {
                    new FieldSpec("MaHoSo", "Mã hồ sơ", "text"),
                    new FieldSpec("MaBenhNhan", "Mã bệnh nhân", "text"),
                    new FieldSpec("HoTen", "Họ và tên", "text"),
                    new FieldSpec("SoCMND", "CCCD/CMND", "text"),
                    new FieldSpec("TrangThai", "Trạng thái hồ sơ", "combo", false, "Tất cả", "Mới", "Đang theo dõi", "Đã đóng/Lưu trữ", "Đã khóa"),
                    new FieldSpec("NgayTao", "Ngày tạo hồ sơ", "date")
                },
                SampleRows = new[]
                {
                    new[] { "HS0001", "BN0001", "Nguyễn Văn An", "079000000001", "Đang theo dõi", "10/10/2026" },
                    new[] { "HS0002", "BN0002", "Trần Thị Bình", "079000000002", "Mới", "12/10/2026" }
                }
            };
        }
    }
}
