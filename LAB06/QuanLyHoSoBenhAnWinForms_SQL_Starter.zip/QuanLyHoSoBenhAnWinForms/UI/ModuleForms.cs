namespace QuanLyHoSoBenhAnWinForms.UI
{
    public sealed class FrmBenhNhan : FrmCrudBase
    {
        public FrmBenhNhan() : base(ModuleCatalog.BenhNhan()) { }
    }

    public sealed class FrmHoSoBenhAn : FrmCrudBase
    {
        public FrmHoSoBenhAn() : base(ModuleCatalog.HoSoBenhAn()) { }
    }

    public sealed class FrmLichKham : FrmCrudBase
    {
        public FrmLichKham() : base(ModuleCatalog.LichKham()) { }
    }

    public sealed class FrmKhamBenh : FrmCrudBase
    {
        public FrmKhamBenh() : base(ModuleCatalog.KhamBenh()) { }
    }

    public sealed class FrmXetNghiem : FrmCrudBase
    {
        public FrmXetNghiem() : base(ModuleCatalog.XetNghiem()) { }
    }

    public sealed class FrmToaThuoc : FrmCrudBase
    {
        public FrmToaThuoc() : base(ModuleCatalog.ToaThuoc()) { }
    }

    public sealed class FrmThanhToan : FrmCrudBase
    {
        public FrmThanhToan() : base(ModuleCatalog.ThanhToan()) { }
    }
}
