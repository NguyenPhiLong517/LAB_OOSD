using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace QuanLyHoSoBenhAnWinForms.UI
{
    public sealed class FrmMain : Form
    {
        private readonly Color _navy = Color.FromArgb(26, 45, 75);
        private readonly Color _blue = Color.FromArgb(43, 108, 176);
        private readonly Color _background = Color.FromArgb(245, 247, 251);
        private readonly Dictionary<string, Form> _openForms = new Dictionary<string, Form>();
        private Panel _content;

        public FrmMain()
        {
            Text = "Hệ thống quản lý hồ sơ bệnh án";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1360, 850);
            MinimumSize = new Size(1120, 720);
            Font = new Font("Segoe UI", 9F);
            BackColor = _background;
            BuildShell();
            ShowDashboard();
        }

        private void BuildShell()
        {
            var sidebar = new Panel
            {
                Dock = DockStyle.Left,
                Width = 238,
                BackColor = _navy,
                Padding = new Padding(0, 0, 0, 10)
            };

            var brand = new Panel { Dock = DockStyle.Top, Height = 112, BackColor = _navy, Padding = new Padding(18, 18, 10, 10) };
            var brandTitle = new Label
            {
                Text = "MEDCARE",
                AutoSize = true,
                Font = new Font("Segoe UI", 19F, FontStyle.Bold),
                ForeColor = Color.White,
                Location = new Point(16, 17)
            };
            var brandSub = new Label
            {
                Text = "QUẢN LÝ HỒ SƠ BỆNH ÁN",
                AutoSize = true,
                Font = new Font("Segoe UI", 7.8F, FontStyle.Bold),
                ForeColor = Color.FromArgb(190, 207, 229),
                Location = new Point(18, 57)
            };
            brand.Controls.Add(brandTitle);
            brand.Controls.Add(brandSub);

            var nav = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                AutoScroll = true,
                Padding = new Padding(10, 8, 8, 8),
                BackColor = _navy
            };
            nav.Controls.Add(CreateNavButton("Trang chủ", "home"));
            nav.Controls.Add(CreateNavButton("Quản lý bệnh nhân", "patient"));
            nav.Controls.Add(CreateNavButton("Hồ sơ bệnh án", "record"));
            nav.Controls.Add(CreateNavButton("Tra cứu hồ sơ", "search"));
            nav.Controls.Add(CreateNavButton("Lịch khám định kỳ", "appointment"));
            nav.Controls.Add(CreateNavButton("Khám bệnh", "exam"));
            nav.Controls.Add(CreateNavButton("Xét nghiệm", "lab"));
            nav.Controls.Add(CreateNavButton("Lập toa thuốc", "medicine"));
            nav.Controls.Add(CreateNavButton("Thanh toán / Xuất viện", "payment"));
            nav.Controls.Add(CreateNavButton("Báo cáo - Thống kê", "report"));

            sidebar.Controls.Add(nav);
            sidebar.Controls.Add(brand);

            var top = new Panel { Dock = DockStyle.Top, Height = 82, BackColor = Color.White, Padding = new Padding(24, 15, 24, 10) };
            var pageTitle = new Label
            {
                Text = "TRUNG TÂM ĐIỀU HÀNH",
                AutoSize = true,
                Font = new Font("Segoe UI", 15F, FontStyle.Bold),
                ForeColor = _navy,
                Location = new Point(22, 13)
            };
            var sub = new Label
            {
                Text = "Quản lý thông tin hành chính, khám chữa bệnh và viện phí",
                AutoSize = true,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(95, 107, 125),
                Location = new Point(24, 45)
            };
            var user = new Label
            {
                Text = "NHÂN VIÊN  |  HỆ THỐNG NỘI BỘ",
                AutoSize = true,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Bold),
                ForeColor = _blue,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(925, 28)
            };
            top.Controls.Add(pageTitle);
            top.Controls.Add(sub);
            top.Controls.Add(user);
            top.Resize += (s, e) => user.Location = new Point(Math.Max(450, top.ClientSize.Width - user.Width - 24), 28);

            _content = new Panel { Dock = DockStyle.Fill, BackColor = _background, Padding = new Padding(22) };
            _content.Resize += Content_Resize;
            Controls.Add(_content);
            Controls.Add(top);
            Controls.Add(sidebar);
        }

        private Button CreateNavButton(string text, string key)
        {
            var button = new Button
            {
                Text = "   " + text,
                Tag = key,
                Width = 210,
                Height = 43,
                TextAlign = ContentAlignment.MiddleLeft,
                FlatStyle = FlatStyle.Flat,
                BackColor = _navy,
                ForeColor = Color.FromArgb(224, 233, 244),
                Font = new Font("Segoe UI", 9.2F, FontStyle.Regular),
                Cursor = Cursors.Hand,
                Margin = new Padding(0, 3, 0, 3),
                UseVisualStyleBackColor = false
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = Color.FromArgb(42, 66, 102);
            button.Click += (s, e) => Navigate(key);
            return button;
        }

        private void Navigate(string key)
        {
            switch (key)
            {
                case "home": ShowDashboard(); break;
                case "patient": OpenModule(key, () => new FrmBenhNhan()); break;
                case "record": OpenModule(key, () => new FrmHoSoBenhAn()); break;
                case "search": OpenModule(key, () => new FrmTraCuuHoSo()); break;
                case "appointment": OpenModule(key, () => new FrmLichKham()); break;
                case "exam": OpenModule(key, () => new FrmKhamBenh()); break;
                case "lab": OpenModule(key, () => new FrmXetNghiem()); break;
                case "medicine": OpenModule(key, () => new FrmToaThuoc()); break;
                case "payment": OpenModule(key, () => new FrmThanhToan()); break;
                case "report": OpenModule(key, () => new FrmThongKe()); break;
            }
        }

        private void OpenModule(string key, Func<Form> createForm)
        {
            Form form;
            if (_openForms.TryGetValue(key, out form) && !form.IsDisposed)
            {
                if (form.WindowState == FormWindowState.Minimized) form.WindowState = FormWindowState.Normal;
                form.Activate();
                return;
            }

            form = createForm();
            form.FormClosed += (s, e) => _openForms.Remove(key);
            _openForms[key] = form;
            form.Show(this);
        }

        private void ShowDashboard()
        {
            _content.SuspendLayout();
            _content.Controls.Clear();

            var title = new Label
            {
                Text = "Tổng quan hệ thống",
                AutoSize = true,
                Font = new Font("Segoe UI", 18F, FontStyle.Bold),
                ForeColor = _navy,
                Location = new Point(2, 0)
            };
            var subtitle = new Label
            {
                Text = "Màn hình minh họa điều hướng và các chỉ số tổng quan. Số liệu dưới đây là dữ liệu mẫu.",
                AutoSize = true,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(95, 107, 125),
                Location = new Point(4, 37)
            };
            _content.Controls.Add(title);
            _content.Controls.Add(subtitle);

            var cards = new FlowLayoutPanel
            {
                Location = new Point(0, 85),
                Size = new Size(Math.Max(800, _content.ClientSize.Width - 10), 132),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                AutoScroll = true,
                BackColor = _background
            };
            cards.Controls.Add(CreateStatCard("BỆNH NHÂN", "1.248", "Tổng số hồ sơ bệnh nhân (mẫu)", Color.FromArgb(43, 108, 176)));
            cards.Controls.Add(CreateStatCard("LỊCH HẸN", "86", "Lịch hẹn trong kỳ (mẫu)", Color.FromArgb(38, 132, 91)));
            cards.Controls.Add(CreateStatCard("CHỜ KHÁM", "12", "Phiếu khám đang chờ (mẫu)", Color.FromArgb(188, 126, 42)));
            cards.Controls.Add(CreateStatCard("CHỜ THANH TOÁN", "04", "Hóa đơn cần xử lý (mẫu)", Color.FromArgb(151, 73, 104)));
            _content.Controls.Add(cards);

            var actionsPanel = new Panel
            {
                Location = new Point(0, 245),
                Size = new Size(Math.Max(800, _content.ClientSize.Width - 10), 285),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = Color.White,
                Padding = new Padding(20)
            };
            actionsPanel.Paint += (s, e) =>
            {
                using (var pen = new Pen(Color.FromArgb(220, 226, 235)))
                    e.Graphics.DrawRectangle(pen, 0, 0, actionsPanel.Width - 1, actionsPanel.Height - 1);
            };
            var quickTitle = new Label
            {
                Text = "TRUY CẬP NHANH",
                AutoSize = true,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = _navy,
                Location = new Point(20, 18)
            };
            var quickText = new Label
            {
                Text = "Chọn một nghiệp vụ để mở màn hình tương ứng. Mỗi màn hình hiện có dữ liệu giả lập trong bộ nhớ;\nchưa thực hiện đọc/ghi SQL Server.",
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(75, 88, 108),
                Location = new Point(22, 53)
            };
            actionsPanel.Controls.Add(quickTitle);
            actionsPanel.Controls.Add(quickText);
            var quickButtons = new FlowLayoutPanel
            {
                Location = new Point(18, 110),
                Size = new Size(actionsPanel.Width - 35, 115),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                BackColor = Color.White
            };
            quickButtons.Controls.Add(CreateQuickButton("+ Đăng ký bệnh nhân", () => OpenModule("patient", () => new FrmBenhNhan())));
            quickButtons.Controls.Add(CreateQuickButton("Tra cứu hồ sơ", () => OpenModule("search", () => new FrmTraCuuHoSo())));
            quickButtons.Controls.Add(CreateQuickButton("Đặt lịch khám", () => OpenModule("appointment", () => new FrmLichKham())));
            quickButtons.Controls.Add(CreateQuickButton("Khám bệnh", () => OpenModule("exam", () => new FrmKhamBenh())));
            quickButtons.Controls.Add(CreateQuickButton("Thanh toán", () => OpenModule("payment", () => new FrmThanhToan())));
            actionsPanel.Controls.Add(quickButtons);
            _content.Controls.Add(actionsPanel);

            _content.ResumeLayout();
        }

        private void Content_Resize(object sender, EventArgs e)
        {
            foreach (Control control in _content.Controls)
            {
                if (control is FlowLayoutPanel && control.Top == 85)
                    control.Width = Math.Max(800, _content.ClientSize.Width - 10);
                if (control is Panel && control.Top == 245)
                    control.Width = Math.Max(800, _content.ClientSize.Width - 10);
            }
        }

        private Control CreateStatCard(string title, string number, string description, Color accent)
        {
            var card = new Panel
            {
                Width = 245,
                Height = 110,
                BackColor = Color.White,
                Margin = new Padding(0, 0, 15, 0),
                Padding = new Padding(13)
            };
            card.Paint += (s, e) =>
            {
                using (var pen = new Pen(Color.FromArgb(220, 226, 235)))
                    e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
                using (var brush = new SolidBrush(accent))
                    e.Graphics.FillRectangle(brush, 0, 0, 5, card.Height);
            };
            var heading = new Label { Text = title, AutoSize = true, ForeColor = Color.FromArgb(95, 107, 125), Font = new Font("Segoe UI", 8.3F, FontStyle.Bold), Location = new Point(16, 11) };
            var value = new Label { Text = number, AutoSize = true, ForeColor = _navy, Font = new Font("Segoe UI", 21F, FontStyle.Bold), Location = new Point(14, 29) };
            var desc = new Label { Text = description, AutoSize = true, ForeColor = Color.FromArgb(110, 120, 136), Font = new Font("Segoe UI", 7.8F), Location = new Point(16, 79) };
            card.Controls.Add(heading);
            card.Controls.Add(value);
            card.Controls.Add(desc);
            return card;
        }

        private Button CreateQuickButton(string text, Action action)
        {
            var button = new Button
            {
                Text = text,
                Width = 190,
                Height = 40,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(237, 244, 252),
                ForeColor = _blue,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(0, 0, 12, 10),
                UseVisualStyleBackColor = false
            };
            button.FlatAppearance.BorderColor = Color.FromArgb(211, 225, 243);
            button.Click += (s, e) => action();
            return button;
        }
    }
}
