using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using System.Data.SqlClient;
using QuanLyHoSoBenhAnWinForms.Data;

namespace QuanLyHoSoBenhAnWinForms.UI
{
    /// <summary>
    /// Form dùng chung cho các màn hình danh mục/nghiệp vụ.
    /// Module có DbTableName sẽ dùng SQL Server; module còn lại vẫn dùng dữ liệu mẫu.
    /// </summary>
    public class FrmCrudBase : Form
    {
        private readonly ModuleConfig _config;
        private readonly Dictionary<string, Control> _editors = new Dictionary<string, Control>();
        private readonly DataTable _table = new DataTable();
        private readonly BindingSource _bindingSource = new BindingSource();
        private DataView _view;
        private DataGridView _grid;
        private TextBox _txtSearch;
        private DataRow _selectedRow;
        private bool _suppressGridSelection;

        private readonly Color _navy = Color.FromArgb(26, 45, 75);
        private readonly Color _blue = Color.FromArgb(43, 108, 176);
        private readonly Color _background = Color.FromArgb(245, 247, 251);
        private readonly Color _border = Color.FromArgb(220, 226, 235);

        internal FrmCrudBase(ModuleConfig config)
        {
            _config = config ?? throw new ArgumentNullException("config");
            Text = _config.Title;
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1240, 820);
            MinimumSize = new Size(1020, 680);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular);
            BackColor = _background;
            BuildTable();
            BuildInterface();
        }

        private void BuildTable()
        {
            foreach (FieldSpec field in _config.Fields)
                _table.Columns.Add(field.Name, typeof(string));

            if (!String.IsNullOrWhiteSpace(_config.DbTableName))
            {
                try
                {
                    LoadDatabaseRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(
                        "Không tải được dữ liệu SQL Server cho màn hình '" + _config.Title + "'.\r\n\r\n" +
                        "Hãy kiểm tra SQL Server, database và chuỗi kết nối trong App.config.\r\n\r\nChi tiết: " + ex.Message,
                        "Lỗi kết nối cơ sở dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (_config.SampleRows != null)
            {
                foreach (string[] values in _config.SampleRows)
                {
                    DataRow row = _table.NewRow();
                    for (int i = 0; i < _config.Fields.Length; i++)
                        row[i] = values != null && i < values.Length ? (values[i] ?? String.Empty) : String.Empty;
                    _table.Rows.Add(row);
                }
            }

            _view = new DataView(_table);
            _bindingSource.DataSource = _view;
        }

        private void BuildInterface()
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 5,
                Padding = new Padding(12),
                BackColor = _background
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 76F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58F));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, _config.Fields.Any(f => f.Kind == "memo") ? 34F : 28F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, _config.Fields.Any(f => f.Kind == "memo") ? 66F : 72F));

            root.Controls.Add(BuildHeader(), 0, 0);
            root.Controls.Add(BuildSearchBar(), 0, 1);
            root.Controls.Add(BuildFieldsPanel(), 0, 2);
            root.Controls.Add(BuildActionsPanel(), 0, 3);
            root.Controls.Add(BuildGridPanel(), 0, 4);
            Controls.Add(root);
        }

        private Control BuildHeader()
        {
            var panel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(16, 9, 16, 8)
            };
            panel.Paint += (s, e) =>
            {
                using (var pen = new Pen(_border))
                    e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
            };

            var title = new Label
            {
                Text = _config.Title,
                AutoSize = true,
                Font = new Font("Segoe UI", 15F, FontStyle.Bold),
                ForeColor = _navy,
                Location = new Point(14, 8)
            };
            var description = new Label
            {
                Text = _config.Description,
                AutoSize = true,
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(95, 107, 125),
                Location = new Point(16, 42)
            };
            panel.Controls.Add(title);
            panel.Controls.Add(description);
            return panel;
        }

        private Control BuildSearchBar()
        {
            var panel = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(10, 8, 10, 6) };
            var label = new Label
            {
                Text = "Từ khóa:", AutoSize = true, ForeColor = _navy,
                Location = new Point(8, 14), Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };
            _txtSearch = new TextBox
            {
                Location = new Point(82, 9), Width = 470, Height = 28,
                Font = new Font("Segoe UI", 9F)
            };
            var searchToolTip = new ToolTip();
            searchToolTip.SetToolTip(_txtSearch, _config.SearchPlaceholder);

            var btnSearch = MakeButton("Tìm kiếm", _blue, Color.White, 100);
            btnSearch.Location = new Point(565, 7);
            btnSearch.Click += (s, e) => ApplySearch();

            var btnClear = MakeButton("Bỏ lọc", Color.FromArgb(232, 237, 244), _navy, 90);
            btnClear.Location = new Point(673, 7);
            btnClear.Click += (s, e) => ClearSearch();

            panel.Controls.Add(label);
            panel.Controls.Add(_txtSearch);
            panel.Controls.Add(btnSearch);
            panel.Controls.Add(btnClear);
            return panel;
        }

        private Control BuildFieldsPanel()
        {
            var outer = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(10),
                BorderStyle = BorderStyle.FixedSingle
            };
            var heading = new Label
            {
                Text = _config.AllowEdit ? "THÔNG TIN NGHIỆP VỤ" : "TIÊU CHÍ / THÔNG TIN HỒ SƠ",
                Dock = DockStyle.Top,
                Height = 25,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = _navy
            };
            var flow = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                WrapContents = true,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(0, 5, 0, 0),
                BackColor = Color.White
            };

            foreach (FieldSpec field in _config.Fields)
            {
                var box = new Panel
                {
                    Width = field.Kind == "memo" ? 345 : 255,
                    Height = field.Kind == "memo" ? 88 : 62,
                    Margin = new Padding(5, 4, 5, 2),
                    BackColor = Color.White
                };
                var label = new Label
                {
                    Text = field.Label + (field.Required && _config.AllowEdit ? " *" : ""),
                    Location = new Point(1, 0),
                    AutoSize = true,
                    ForeColor = field.Required && _config.AllowEdit ? Color.FromArgb(151, 58, 58) : _navy,
                    Font = new Font("Segoe UI", 8.5F, FontStyle.Bold)
                };
                Control editor = CreateEditor(field);
                editor.Location = new Point(1, 23);
                editor.Width = box.Width - 7;
                if (field.Kind == "memo") editor.Height = 58;
                else editor.Height = 28;
                editor.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                _editors[field.Name] = editor;
                box.Controls.Add(label);
                box.Controls.Add(editor);
                flow.Controls.Add(box);
            }

            outer.Controls.Add(flow);
            outer.Controls.Add(heading);
            return outer;
        }

        private Control CreateEditor(FieldSpec field)
        {
            if (field.Kind == "date" || field.Kind == "datetime")
            {
                return new DateTimePicker
                {
                    Format = DateTimePickerFormat.Custom,
                    CustomFormat = field.Kind == "datetime" ? "dd/MM/yyyy HH:mm" : "dd/MM/yyyy",
                    ShowUpDown = field.Kind == "datetime",
                    Value = DateTime.Now,
                    Font = new Font("Segoe UI", 9F)
                };
            }
            if (field.Kind == "combo")
            {
                var combo = new ComboBox
                {
                    DropDownStyle = ComboBoxStyle.DropDownList,
                    Font = new Font("Segoe UI", 9F)
                };
                combo.Items.AddRange(field.Options.Cast<object>().ToArray());
                if (combo.Items.Count > 0) combo.SelectedIndex = 0;
                return combo;
            }
            if (field.Kind == "number" || field.Kind == "money")
            {
                return new NumericUpDown
                {
                    Minimum = 0,
                    Maximum = 999999999,
                    DecimalPlaces = field.Kind == "money" ? 2 : 0,
                    ThousandsSeparator = true,
                    TextAlign = HorizontalAlignment.Right,
                    Font = new Font("Segoe UI", 9F)
                };
            }
            if (field.Kind == "memo")
            {
                return new TextBox
                {
                    Multiline = true,
                    ScrollBars = ScrollBars.Vertical,
                    Font = new Font("Segoe UI", 9F)
                };
            }
            return new TextBox { Font = new Font("Segoe UI", 9F) };
        }

        private Control BuildActionsPanel()
        {
            var panel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Padding = new Padding(0, 8, 0, 0),
                BackColor = _background
            };

            if (_config.AllowEdit)
            {
                var btnNew = MakeButton("Thêm mới", _blue, Color.White, 105);
                btnNew.Click += (s, e) => ClearEditors();
                var btnSave = MakeButton("Lưu dữ liệu", Color.FromArgb(38, 132, 91), Color.White, 112);
                btnSave.Click += (s, e) => SaveRecord();
                var btnDelete = MakeButton("Xóa bản ghi", Color.FromArgb(177, 63, 63), Color.White, 112);
                btnDelete.Click += (s, e) => DeleteRecord();
                var btnReset = MakeButton("Làm mới", Color.FromArgb(232, 237, 244), _navy, 100);
                btnReset.Click += (s, e) => { ClearSearch(); ClearEditors(); };
                panel.Controls.Add(btnNew);
                panel.Controls.Add(btnSave);
                panel.Controls.Add(btnDelete);
                panel.Controls.Add(btnReset);
            }
            else
            {
                var note = new Label
                {
                    Text = "Chọn dòng kết quả để xem thông tin. Dữ liệu hiện tại chỉ là dữ liệu mẫu.",
                    AutoSize = true,
                    ForeColor = Color.FromArgb(95, 107, 125),
                    Font = new Font("Segoe UI", 9F),
                    Margin = new Padding(5, 9, 5, 5)
                };
                panel.Controls.Add(note);
            }
            return panel;
        }

        private Control BuildGridPanel()
        {
            var panel = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(1) };
            _grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                DataSource = _bindingSource,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None,
                RowHeadersVisible = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                GridColor = _border,
                EnableHeadersVisualStyles = false,
                Font = new Font("Segoe UI", 9F),
                ColumnHeadersHeight = 36,
                RowTemplate = { Height = 30 }
            };
            _grid.ColumnHeadersDefaultCellStyle.BackColor = _navy;
            _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            _grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(220, 235, 252);
            _grid.DefaultCellStyle.SelectionForeColor = Color.FromArgb(30, 45, 65);
            _grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 253);
            _grid.SelectionChanged += Grid_SelectionChanged;
            _grid.DataError += (s, e) => { e.ThrowException = false; };
            panel.Controls.Add(_grid);
            return panel;
        }

        private Button MakeButton(string text, Color backColor, Color foreColor, int width)
        {
            return new Button
            {
                Text = text,
                Width = width,
                Height = 34,
                FlatStyle = FlatStyle.Flat,
                BackColor = backColor,
                ForeColor = foreColor,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(0, 0, 8, 0),
                UseVisualStyleBackColor = false
            };
        }

        private void ApplySearch()
        {
            string keyword = (_txtSearch.Text ?? String.Empty).Trim();
            if (String.IsNullOrWhiteSpace(keyword))
            {
                _view.RowFilter = String.Empty;
                return;
            }

            string escaped = keyword.Replace("'", "''").Replace("[", "[[]").Replace("%", "[%]").Replace("*", "[*]");
            var filters = _table.Columns.Cast<DataColumn>()
                .Select(c => "CONVERT([" + c.ColumnName + "], 'System.String') LIKE '%" + escaped + "%'");
            _view.RowFilter = String.Join(" OR ", filters);
        }

        private void ClearSearch()
        {
            _txtSearch.Text = String.Empty;
            _view.RowFilter = String.Empty;
        }

        private void Grid_SelectionChanged(object sender, EventArgs e)
        {
            if (_suppressGridSelection || _grid.CurrentRow == null)
                return;

            var drv = _grid.CurrentRow.DataBoundItem as DataRowView;
            if (drv == null) return;
            _selectedRow = drv.Row;
            FillEditorsFromRow(_selectedRow);
        }

        private void FillEditorsFromRow(DataRow row)
        {
            foreach (FieldSpec field in _config.Fields)
            {
                Control editor = _editors[field.Name];
                string value = Convert.ToString(row[field.Name], CultureInfo.CurrentCulture) ?? String.Empty;
                if (editor is DateTimePicker)
                {
                    DateTime date;
                    if (DateTime.TryParse(value, CultureInfo.GetCultureInfo("vi-VN"), DateTimeStyles.None, out date) || DateTime.TryParse(value, out date))
                        ((DateTimePicker)editor).Value = date < ((DateTimePicker)editor).MinDate ? ((DateTimePicker)editor).MinDate : (date > ((DateTimePicker)editor).MaxDate ? ((DateTimePicker)editor).MaxDate : date);
                }
                else if (editor is ComboBox)
                {
                    var combo = (ComboBox)editor;
                    int index = combo.Items.IndexOf(value);
                    if (index >= 0) combo.SelectedIndex = index;
                }
                else if (editor is NumericUpDown)
                {
                    decimal amount;
                    if (Decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out amount) || Decimal.TryParse(value, out amount))
                    {
                        var numeric = (NumericUpDown)editor;
                        if (amount < numeric.Minimum) amount = numeric.Minimum;
                        if (amount > numeric.Maximum) amount = numeric.Maximum;
                        numeric.Value = amount;
                    }
                }
                else if (editor is TextBox)
                {
                    editor.Text = value;
                }
            }
        }

        private void ClearEditors()
        {
            _suppressGridSelection = true;
            _selectedRow = null;
            foreach (FieldSpec field in _config.Fields)
            {
                Control editor = _editors[field.Name];
                if (editor is TextBox) editor.Text = String.Empty;
                else if (editor is DateTimePicker) ((DateTimePicker)editor).Value = DateTime.Today;
                else if (editor is ComboBox)
                {
                    var combo = (ComboBox)editor;
                    if (combo.Items.Count > 0) combo.SelectedIndex = 0;
                }
                else if (editor is NumericUpDown) ((NumericUpDown)editor).Value = 0;
            }
            _grid.ClearSelection();
            _grid.CurrentCell = null;
            _suppressGridSelection = false;
        }

        private string ReadEditor(FieldSpec field)
        {
            Control editor = _editors[field.Name];
            if (editor is DateTimePicker)
                return ((DateTimePicker)editor).Value.ToString(field.Kind == "datetime" ? "dd/MM/yyyy HH:mm" : "dd/MM/yyyy");
            if (editor is ComboBox) return Convert.ToString(((ComboBox)editor).SelectedItem) ?? String.Empty;
            if (editor is NumericUpDown) return ((NumericUpDown)editor).Value.ToString(CultureInfo.InvariantCulture);
            return editor.Text.Trim();
        }

        private void SaveRecord()
        {
            foreach (FieldSpec field in _config.Fields)
            {
                if (field.Required && String.IsNullOrWhiteSpace(ReadEditor(field)))
                {
                    MessageBox.Show("Vui lòng nhập trường bắt buộc: " + field.Label, "Thiếu thông tin", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    _editors[field.Name].Focus();
                    return;
                }
            }

            if (!String.IsNullOrWhiteSpace(_config.DbTableName))
            {
                try
                {
                    SaveDatabaseRecord();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không thể lưu vào SQL Server.\r\n\r\n" + ex.Message,
                        "Lỗi lưu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }

            string keyField = _config.Fields[0].Name;
            string keyValue = ReadEditor(_config.Fields[0]);
            if (_selectedRow == null && !String.IsNullOrWhiteSpace(keyValue))
            {
                foreach (DataRow existing in _table.Rows)
                {
                    if (existing.RowState != DataRowState.Deleted && String.Equals(Convert.ToString(existing[keyField]), keyValue, StringComparison.OrdinalIgnoreCase))
                    {
                        MessageBox.Show("Mã " + _config.Fields[0].Label + " đã tồn tại trong dữ liệu mẫu.", "Trùng mã", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        _editors[keyField].Focus();
                        return;
                    }
                }
            }

            DataRow target = _selectedRow;
            if (target == null)
                target = _table.NewRow();

            for (int i = 0; i < _config.Fields.Length; i++)
                target[_config.Fields[i].Name] = ReadEditor(_config.Fields[i]);

            if (target.RowState == DataRowState.Detached)
                _table.Rows.Add(target);

            MessageBox.Show("Đã cập nhật dữ liệu trong bộ nhớ. Khi nối CSDL, thao tác này cần được thay bằng lệnh INSERT/UPDATE SQL.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearEditors();
        }

        private void DeleteRecord()
        {
            if (_selectedRow == null || _selectedRow.RowState == DataRowState.Deleted)
            {
                MessageBox.Show("Hãy chọn một dòng trong bảng cần xóa.", "Chưa chọn dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool sqlMode = !String.IsNullOrWhiteSpace(_config.DbTableName);
            DialogResult answer = MessageBox.Show(
                sqlMode ? "Bạn có chắc muốn xóa bản ghi này khỏi cơ sở dữ liệu?" : "Bạn có chắc muốn xóa bản ghi mẫu đang chọn? Thao tác này chỉ ảnh hưởng dữ liệu trong bộ nhớ.",
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (answer != DialogResult.Yes) return;

            if (sqlMode)
            {
                try
                {
                    DeleteDatabaseRecord();
                    LoadDatabaseRows();
                    ClearEditors();
                    MessageBox.Show("Đã xóa bản ghi khỏi SQL Server.", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không thể xóa bản ghi. Có thể dữ liệu đang được bảng khác tham chiếu.\r\n\r\n" + ex.Message,
                        "Lỗi xóa dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }

            _selectedRow.Delete();
            ClearEditors();
        }

        private string QuoteIdentifier(string name)
        {
            // Tên bảng/cột lấy từ cấu hình nội bộ, không lấy từ dữ liệu người dùng.
            return "[" + name.Replace("]", "]]" ) + "]";
        }

        private string[] GetKeyFields()
        {
            if (_config.KeyFields != null && _config.KeyFields.Length > 0)
                return _config.KeyFields;
            return new[] { _config.Fields[0].Name };
        }

        private object ReadDatabaseValue(FieldSpec field)
        {
            string value = ReadEditor(field);
            if (String.IsNullOrWhiteSpace(value)) return DBNull.Value;

            if (field.Kind == "date" || field.Kind == "datetime")
            {
                string format = field.Kind == "datetime" ? "dd/MM/yyyy HH:mm" : "dd/MM/yyyy";
                return DateTime.ParseExact(value, format, CultureInfo.GetCultureInfo("vi-VN"));
            }
            if (field.Kind == "number" || field.Kind == "money")
                return Decimal.Parse(value, NumberStyles.Any, CultureInfo.InvariantCulture);
            return value;
        }

        private string FormatDatabaseValue(FieldSpec field, object value)
        {
            if (value == null || value == DBNull.Value) return String.Empty;
            if (field.Kind == "date") return Convert.ToDateTime(value).ToString("dd/MM/yyyy");
            if (field.Kind == "datetime") return Convert.ToDateTime(value).ToString("dd/MM/yyyy HH:mm");
            if (field.Kind == "number" || field.Kind == "money")
                return Convert.ToString(value, CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.CurrentCulture) ?? String.Empty;
        }

        private void LoadDatabaseRows()
        {
            string columns = String.Join(", ", _config.Fields.Select(f => QuoteIdentifier(f.Name)));
            string sql = "SELECT " + columns + " FROM " + QuoteIdentifier("dbo") + "." + QuoteIdentifier(_config.DbTableName);
            using (SqlConnection connection = Db.GetConnection())
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    _table.Rows.Clear();
                    while (reader.Read())
                    {
                        DataRow row = _table.NewRow();
                        foreach (FieldSpec field in _config.Fields)
                            row[field.Name] = FormatDatabaseValue(field, reader[field.Name]);
                        _table.Rows.Add(row);
                    }
                }
            }
            if (_view != null) _view.RowFilter = String.Empty;
        }

        private void SaveDatabaseRecord()
        {
            bool insert = _selectedRow == null;
            string[] keys = GetKeyFields();
            var oldKeys = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
            if (!insert)
            {
                foreach (string key in keys)
                    oldKeys[key] = _selectedRow[key];
            }

            using (SqlConnection connection = Db.GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = connection;
                    if (insert)
                    {
                        string columnList = String.Join(", ", _config.Fields.Select(f => QuoteIdentifier(f.Name)));
                        string parameterList = String.Join(", ", _config.Fields.Select((f, i) => "@p" + i));
                        command.CommandText = "INSERT INTO " + QuoteIdentifier("dbo") + "." + QuoteIdentifier(_config.DbTableName) +
                            " (" + columnList + ") VALUES (" + parameterList + ")";
                        for (int i = 0; i < _config.Fields.Length; i++)
                            command.Parameters.AddWithValue("@p" + i, ReadDatabaseValue(_config.Fields[i]));
                    }
                    else
                    {
                        FieldSpec[] updates = _config.Fields.Where(f => !keys.Contains(f.Name, StringComparer.OrdinalIgnoreCase)).ToArray();
                        if (updates.Length == 0) throw new InvalidOperationException("Không có trường nào để cập nhật.");
                        string setClause = String.Join(", ", updates.Select((f, i) => QuoteIdentifier(f.Name) + " = @v" + i));
                        string whereClause = String.Join(" AND ", keys.Select((k, i) => QuoteIdentifier(k) + " = @k" + i));
                        command.CommandText = "UPDATE " + QuoteIdentifier("dbo") + "." + QuoteIdentifier(_config.DbTableName) +
                            " SET " + setClause + " WHERE " + whereClause;
                        for (int i = 0; i < updates.Length; i++)
                            command.Parameters.AddWithValue("@v" + i, ReadDatabaseValue(updates[i]));
                        for (int i = 0; i < keys.Length; i++)
                            command.Parameters.AddWithValue("@k" + i, oldKeys[keys[i]] ?? DBNull.Value);
                    }
                    int affected = command.ExecuteNonQuery();
                    if (affected == 0) throw new InvalidOperationException("Không tìm thấy bản ghi cần cập nhật.");
                }
            }

            LoadDatabaseRows();
            ClearEditors();
            MessageBox.Show(insert ? "Đã thêm bệnh nhân vào SQL Server." : "Đã cập nhật bệnh nhân trong SQL Server.",
                "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void DeleteDatabaseRecord()
        {
            string[] keys = GetKeyFields();
            using (SqlConnection connection = Db.GetConnection())
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = connection;
                string whereClause = String.Join(" AND ", keys.Select((k, i) => QuoteIdentifier(k) + " = @k" + i));
                command.CommandText = "DELETE FROM " + QuoteIdentifier("dbo") + "." + QuoteIdentifier(_config.DbTableName) + " WHERE " + whereClause;
                for (int i = 0; i < keys.Length; i++)
                    command.Parameters.AddWithValue("@k" + i, _selectedRow[keys[i]] ?? DBNull.Value);
                connection.Open();
                if (command.ExecuteNonQuery() == 0)
                    throw new InvalidOperationException("Không tìm thấy bản ghi cần xóa.");
            }
        }
    }
}
