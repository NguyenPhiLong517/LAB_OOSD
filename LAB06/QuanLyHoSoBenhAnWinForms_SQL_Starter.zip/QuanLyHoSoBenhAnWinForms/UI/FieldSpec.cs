using System;

namespace QuanLyHoSoBenhAnWinForms.UI
{
    internal sealed class FieldSpec
    {
        public string Name { get; private set; }
        public string Label { get; private set; }
        public string Kind { get; private set; }
        public string[] Options { get; private set; }
        public bool Required { get; private set; }

        public FieldSpec(string name, string label, string kind, bool required = false, params string[] options)
        {
            Name = name;
            Label = label;
            Kind = kind;
            Required = required;
            Options = options ?? new string[0];
        }
    }

    internal sealed class ModuleConfig
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public FieldSpec[] Fields { get; set; }
        public string[][] SampleRows { get; set; }
        // Nếu có DbTableName, form sẽ đọc/ghi trực tiếp bảng SQL Server này.
        // Các module khác chưa khai báo DbTableName vẫn dùng dữ liệu mẫu.
        public string DbTableName { get; set; }
        public string[] KeyFields { get; set; }
        public bool AllowEdit { get; set; }
        public string SearchPlaceholder { get; set; }

        public ModuleConfig()
        {
            AllowEdit = true;
            SearchPlaceholder = "Nhập từ khóa để tìm kiếm...";
        }
    }
}
