using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLyHoSoBenhAnWinForms.UI
{
    public sealed class FrmThongKe : Form
    {
        private readonly Color _navy = Color.FromArgb(26, 45, 75);
        private readonly Color _blue = Color.FromArgb(43, 108, 176);
        private DateTimePicker _from;
        private DateTimePicker _to;
        private DataGridView _grid;
        private DataTable _report;

        public FrmThongKe()
        {
            Text = "Báo cáo - Thống kê";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1180, 760);
            MinimumSize = new Size(980, 640);
            Font = new Font("Segoe UI", 9F);
            BackColor = Color.FromArgb(245, 247, 251);
            BuildInterface();
            LoadSampleReport();
        }

        private void BuildInterface()
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 4,
                Padding = new Padding(14),
                BackColor = Color.FromArgb(245, 247, 251)
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 66F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 130F));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            var header = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(15, 10, 15, 7) };
            var title = new Label { Text = "BÁO CÁO - THỐNG KÊ", AutoSize = true, Font = new Font("Segoe UI", 15F, FontStyle.Bold), ForeColor = _navy, Location = new Point(13, 8) };
            var sub = new Label { Text = "Tổng hợp số lượt khám, lịch hẹn, xét nghiệm, toa thuốc và thanh toán theo khoảng thời gian.", AutoSize = true, ForeColor = Color.FromArgb(95, 107, 125), Location = new Point(15, 42) };
            header.Controls.Add(title);
            header.Controls.Add(sub);

            var filter = new FlowLayoutPanel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(12, 12, 10, 5), WrapContents = false };
            filter.Controls.Add(new Label { Text = "Từ ngày:", AutoSize = true, ForeColor = _navy, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Margin = new Padding(0, 8, 8, 0) });
            _from = NewDatePicker(DateTime.Today.AddDays(-30));
            filter.Controls.Add(_from);
            filter.Controls.Add(new Label { Text = "Đến ngày:", AutoSize = true, ForeColor = _navy, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Margin = new Padding(18, 8, 8, 0) });
            _to = NewDatePicker(DateTime.Today);
            filter.Controls.Add(_to);
            var btnView = NewButton("Xem báo cáo", _blue, Color.White, 125);
            btnView.Click += (s, e) => ApplyDateFilter();
            filter.Controls.Add(btnView);
            var btnExport = NewButton("Xuất CSV", Color.FromArgb(38, 132, 91), Color.White, 105);
            btnExport.Click += (s, e) => ExportCsv();
            filter.Controls.Add(btnExport);

            var stats = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoScroll = true, BackColor = Color.FromArgb(245, 247, 251), Padding = new Padding(0, 7, 0, 0) };
            stats.Controls.Add(StatCard("Lượt khám", "128", "Dữ liệu minh họa"));
            stats.Controls.Add(StatCard("Xét nghiệm", "76", "Dữ liệu minh họa"));
            stats.Controls.Add(StatCard("Lịch hẹn", "42", "Dữ liệu minh họa"));
            stats.Controls.Add(StatCard("Đã thanh toán", "92", "Dữ liệu minh họa"));

            _grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                GridColor = Color.FromArgb(220, 226, 235),
                EnableHeadersVisualStyles = false,
                Font = new Font("Segoe UI", 9F),
                ColumnHeadersHeight = 36
            };
            _grid.ColumnHeadersDefaultCellStyle.BackColor = _navy;
            _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            _grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            _grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 253);

            root.Controls.Add(header, 0, 0);
            root.Controls.Add(filter, 0, 1);
            root.Controls.Add(stats, 0, 2);
            root.Controls.Add(_grid, 0, 3);
            Controls.Add(root);
        }

        private DateTimePicker NewDatePicker(DateTime date)
        {
            return new DateTimePicker { Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy", Value = date, Width = 130, Height = 29, Font = new Font("Segoe UI", 9F), Margin = new Padding(0, 3, 0, 0) };
        }

        private Button NewButton(string text, Color background, Color foreground, int width)
        {
            return new Button { Text = text, Width = width, Height = 34, FlatStyle = FlatStyle.Flat, BackColor = background, ForeColor = foreground, Font = new Font("Segoe UI", 9F, FontStyle.Bold), Cursor = Cursors.Hand, Margin = new Padding(14, 0, 0, 0), UseVisualStyleBackColor = false };
        }

        private Control StatCard(string label, string value, string note)
        {
            var card = new Panel { Width = 205, Height = 105, BackColor = Color.White, Margin = new Padding(0, 0, 13, 0), Padding = new Padding(12) };
            card.Paint += (s, e) =>
            {
                using (var pen = new Pen(Color.FromArgb(220, 226, 235))) e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
            };
            card.Controls.Add(new Label { Text = label.ToUpperInvariant(), AutoSize = true, ForeColor = Color.FromArgb(95, 107, 125), Font = new Font("Segoe UI", 8.2F, FontStyle.Bold), Location = new Point(11, 9) });
            card.Controls.Add(new Label { Text = value, AutoSize = true, ForeColor = _navy, Font = new Font("Segoe UI", 20F, FontStyle.Bold), Location = new Point(10, 28) });
            card.Controls.Add(new Label { Text = note, AutoSize = true, ForeColor = Color.FromArgb(110, 120, 136), Font = new Font("Segoe UI", 7.8F), Location = new Point(12, 77) });
            return card;
        }

        private void LoadSampleReport()
        {
            _report = new DataTable();
            _report.Columns.Add("Ngày", typeof(DateTime));
            _report.Columns.Add("Loại thống kê", typeof(string));
            _report.Columns.Add("Số lượng", typeof(int));
            _report.Columns.Add("Ghi chú", typeof(string));
            _report.Rows.Add(DateTime.Today.AddDays(-4), "Lượt khám", 18, "Số liệu mẫu để minh họa báo cáo");
            _report.Rows.Add(DateTime.Today.AddDays(-3), "Xét nghiệm", 11, "Số liệu mẫu để minh họa báo cáo");
            _report.Rows.Add(DateTime.Today.AddDays(-2), "Lịch hẹn", 8, "Số liệu mẫu để minh họa báo cáo");
            _report.Rows.Add(DateTime.Today.AddDays(-1), "Thanh toán", 16, "Số liệu mẫu để minh họa báo cáo");
            _grid.DataSource = _report;
            _grid.Columns["Ngày"].DefaultCellStyle.Format = "dd/MM/yyyy";
        }

        private void ApplyDateFilter()
        {
            if (_from.Value.Date > _to.Value.Date)
            {
                MessageBox.Show("Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.", "Khoảng thời gian không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            DataView view = new DataView(_report);
            view.RowFilter = "[Ngày] >= #" + _from.Value.Date.ToString("MM/dd/yyyy") + "# AND [Ngày] <= #" + _to.Value.Date.ToString("MM/dd/yyyy") + "#";
            _grid.DataSource = view;
        }

        private void ExportCsv()
        {
            using (var dialog = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = "BaoCaoHoSoBenhAn.csv", Title = "Lưu báo cáo" })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                var source = _grid.DataSource as DataView;
                DataTable table = source != null ? source.ToTable() : _report;
                var lines = new System.Collections.Generic.List<string>();
                lines.Add(String.Join(",", table.Columns.Cast<DataColumn>().Select(c => QuoteCsv(c.ColumnName))));
                foreach (DataRow row in table.Rows)
                    lines.Add(String.Join(",", table.Columns.Cast<DataColumn>().Select(c => QuoteCsv(Convert.ToString(row[c])))));
                File.WriteAllText(dialog.FileName, String.Join(Environment.NewLine, lines), new UTF8Encoding(true));
                MessageBox.Show("Đã xuất báo cáo mẫu ra CSV.", "Hoàn tất", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private string QuoteCsv(string value)
        {
            value = value ?? String.Empty;
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }
    }
}
