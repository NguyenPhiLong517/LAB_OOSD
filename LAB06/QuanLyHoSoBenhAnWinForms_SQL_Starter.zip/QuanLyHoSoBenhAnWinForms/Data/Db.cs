using System;
using System.Configuration;
using System.Data.SqlClient;

namespace QuanLyHoSoBenhAnWinForms.Data
{
    /// <summary>
    /// Tạo kết nối SQL Server từ connectionStrings trong App.config.
    /// Mỗi thao tác nên mở kết nối trong using để tự giải phóng tài nguyên.
    /// </summary>
    internal static class Db
    {
        private static string ConnectionString
        {
            get
            {
                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["QuanLyHoSoBenhAn"];
                if (settings == null || String.IsNullOrWhiteSpace(settings.ConnectionString))
                {
                    throw new InvalidOperationException(
                        "Không tìm thấy connection string 'QuanLyHoSoBenhAn' trong App.config.");
                }
                return settings.ConnectionString;
            }
        }

        internal static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        internal static string TestConnection()
        {
            using (SqlConnection connection = GetConnection())
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT DB_NAME();", connection))
                {
                    return Convert.ToString(command.ExecuteScalar());
                }
            }
        }
    }
}
